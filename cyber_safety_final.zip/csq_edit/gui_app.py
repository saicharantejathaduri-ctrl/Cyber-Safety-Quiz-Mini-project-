"""Cyber Safety Quiz desktop GUI.

Uses only the Python standard library + the project core module.
Student accounts and attempts are stored in a local SQLite database;
passwords are stored as salted PBKDF2-HMAC-SHA256 hashes (never plaintext).
"""
from __future__ import annotations

import hashlib
import hmac
import secrets
import sqlite3
from datetime import datetime
from pathlib import Path

import cyber_safety_quiz as core

try:
    import tkinter as tk
    from tkinter import messagebox, ttk
    HAS_TK = True
except ImportError:  # headless / minimal installs
    HAS_TK = False

BASE = Path(__file__).resolve().parent
DB = BASE / "data" / "cyber_safety_gui.db"

# ---------------------------------------------------------------------------
# Database
# ---------------------------------------------------------------------------

class Database:
    """Local SQLite store for student accounts and quiz attempts."""

    def __init__(self, path: Path | str = DB) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(self.path)
        self.conn.execute("PRAGMA foreign_keys=ON")
        self.conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS students(
                id INTEGER PRIMARY KEY,
                username TEXT UNIQUE NOT NULL,
                salt BLOB NOT NULL,
                password_hash BLOB NOT NULL,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS attempts(
                id INTEGER PRIMARY KEY,
                student_id INTEGER NOT NULL
                    REFERENCES students(id) ON DELETE CASCADE,
                category TEXT NOT NULL,
                correct INTEGER NOT NULL,
                total INTEGER NOT NULL,
                percent REAL NOT NULL,
                difficulty TEXT,
                created_at TEXT NOT NULL
            );
            """
        )
        self.conn.commit()

    def register(self, username: str, password: str) -> int | None:
        salt = secrets.token_bytes(16)
        digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 240_000)
        try:
            cur = self.conn.execute(
                "INSERT INTO students(username, salt, password_hash, created_at) "
                "VALUES (?, ?, ?, ?)",
                (username, salt, digest, datetime.now().isoformat(timespec="seconds")),
            )
            self.conn.commit()
            return cur.lastrowid
        except sqlite3.IntegrityError:
            return None

    def login(self, username: str, password: str) -> int | None:
        row = self.conn.execute(
            "SELECT id, salt, password_hash FROM students WHERE username = ?",
            (username,),
        ).fetchone()
        if not row:
            return None
        test = hashlib.pbkdf2_hmac("sha256", password.encode(), row[1], 240_000)
        return row[0] if hmac.compare_digest(test, row[2]) else None

    def save_attempt(
        self,
        sid: int,
        category: str,
        correct: int,
        total: int,
        difficulty: str | None,
    ) -> None:
        self.conn.execute(
            "INSERT INTO attempts"
            "(student_id, category, correct, total, percent, difficulty, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            (
                sid,
                category,
                correct,
                total,
                round(correct / total * 100, 1) if total else 0.0,
                difficulty or "mixed",
                datetime.now().isoformat(timespec="seconds"),
            ),
        )
        self.conn.commit()

    def stats(self, sid: int) -> list[tuple]:
        return self.conn.execute(
            "SELECT category, correct, total, percent, created_at, difficulty "
            "FROM attempts WHERE student_id = ? ORDER BY id DESC",
            (sid,),
        ).fetchall()

    def close(self) -> None:
        self.conn.close()


# ---------------------------------------------------------------------------
# GUI
# ---------------------------------------------------------------------------

if HAS_TK:
    class CyberSafetyGUI(tk.Tk):

        BG = "#0b1220"

        PANEL = "#141f33"

        CARD = "#1b2942"

        TEXT = "#edf3ff"

        MUTED = "#a7b6d0"

        ACCENT = "#53d6b5"

        BLUE = "#79a9ff"

        DANGER = "#f07178"



        def __init__(self) -> None:

            super().__init__()

            self.title("CyberSafe | Cyber Safety Quiz")

            self.geometry("1100x720")

            self.minsize(900, 620)

            self.configure(bg=self.BG)



            self.db = Database()

            self.student_id: int | None = None

            self.username: str | None = None

            self.questions: list[dict] = []

            self.q_index = 0

            self.score = 0

            self.category = "full"

            self.difficulty: str | None = None

            self.started: datetime | None = None

            self._body_canvas: tk.Canvas | None = None



            style = ttk.Style(self)

            style.theme_use("clam")

            style.configure(

                "TCombobox",

                fieldbackground=self.CARD,

                background=self.CARD,

                foreground=self.TEXT,

            )



            self.protocol("WM_DELETE_WINDOW", self._on_close)

            self.show_auth()



        # -- helpers ----------------------------------------------------------



        def clear(self) -> None:

            for w in self.winfo_children():

                w.destroy()

            self._body_canvas = None



        def label(

            self,

            parent: tk.Misc,

            text: str,

            size: int = 12,

            bold: bool = False,

            color: str | None = None,

            wrap: int = 850,

        ) -> tk.Label:

            return tk.Label(

                parent,

                text=text,

                bg=parent.cget("bg"),

                fg=color or self.TEXT,

                font=("Segoe UI", size, "bold" if bold else "normal"),

                wraplength=wrap,

                justify="left",

            )



        def button(

            self,

            parent: tk.Misc,

            text: str,

            cmd,

            primary: bool = False,

        ) -> tk.Button:

            return tk.Button(

                parent,

                text=text,

                command=cmd,

                bg=self.ACCENT if primary else "#263958",

                fg="#071521" if primary else self.TEXT,

                activebackground=self.BLUE,

                activeforeground="#071521",

                relief="flat",

                bd=0,

                padx=18,

                pady=11,

                font=("Segoe UI", 10, "bold"),

                cursor="hand2",

            )



        def card(self, parent: tk.Misc) -> tk.Frame:

            return tk.Frame(

                parent,

                bg=self.CARD,

                highlightthickness=1,

                highlightbackground="#2b3d5d",

                padx=20,

                pady=18,

            )



        def _scrollable_body(self, parent: tk.Misc) -> tk.Frame:

            """Create a scrollable content area and return the inner frame."""

            canvas = tk.Canvas(parent, bg=self.BG, highlightthickness=0)

            scrollbar = ttk.Scrollbar(parent, orient="vertical", command=canvas.yview)

            inner = tk.Frame(canvas, bg=self.BG)



            inner.bind(

                "<Configure>",

                lambda e: canvas.configure(scrollregion=canvas.bbox("all")),

            )

            window_id = canvas.create_window((0, 0), window=inner, anchor="nw")



            def _resize(event):

                canvas.itemconfig(window_id, width=event.width)



            canvas.bind("<Configure>", _resize)

            canvas.configure(yscrollcommand=scrollbar.set)



            def _on_mousewheel(event):

                canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")



            canvas.bind_all("<MouseWheel>", _on_mousewheel)

            # Linux

            canvas.bind_all("<Button-4>", lambda e: canvas.yview_scroll(-1, "units"))

            canvas.bind_all("<Button-5>", lambda e: canvas.yview_scroll(1, "units"))



            scrollbar.pack(side="right", fill="y")

            canvas.pack(side="left", fill="both", expand=True)

            self._body_canvas = canvas

            return inner



        # -- auth -------------------------------------------------------------



        def show_auth(self) -> None:

            self.clear()

            wrap = tk.Frame(self, bg=self.BG)

            wrap.pack(expand=True)



            self.label(wrap, "CYBERSAFE", 30, True, self.ACCENT).pack(pady=(0, 6))

            self.label(

                wrap,

                "Learn smart. Browse safe. Stay protected.",

                12,

                color=self.MUTED,

            ).pack(pady=(0, 24))



            c = self.card(wrap)

            c.pack()

            self.label(c, "Student sign in / registration", 17, True).pack(

                anchor="w", pady=(0, 14)

            )



            self.user = tk.Entry(

                c,

                width=34,

                font=("Segoe UI", 12),

                bg="#0f192b",

                fg=self.TEXT,

                insertbackground=self.TEXT,

                relief="flat",

            )

            self.user.pack(ipady=10, pady=6)

            self.user.insert(0, "")

            self.user.focus_set()



            self.pw = tk.Entry(

                c,

                width=34,

                font=("Segoe UI", 12),

                bg="#0f192b",

                fg=self.TEXT,

                insertbackground=self.TEXT,

                show="•",

                relief="flat",

            )

            self.pw.pack(ipady=10, pady=6)

            self.pw.bind("<Return>", lambda e: self.do_login())



            self.button(c, "Sign in", self.do_login, True).pack(fill="x", pady=(12, 6))

            self.button(c, "Create student account", self.do_register).pack(fill="x")

            self.label(

                c,

                "Passwords are stored as salted PBKDF2 hashes in a local SQLite database.",

                9,

                color=self.MUTED,

            ).pack(pady=(14, 0))



        def credentials(self) -> tuple[str, str] | None:

            u = self.user.get().strip()

            p = self.pw.get()

            if len(u) < 3 or len(u) > 24 or not u.replace("_", "").isalnum():

                messagebox.showwarning(

                    "Check username",

                    "Use 3–24 letters, numbers or underscores.",

                )

                return None

            if len(p) < 8:

                messagebox.showwarning("Password too short", "Use at least 8 characters.")

                return None

            return u, p



        def do_register(self) -> None:

            cp = self.credentials()

            if not cp:

                return

            sid = self.db.register(*cp)

            if sid is None:

                messagebox.showerror("Account exists", "That username is already registered.")

                return

            self.student_id = sid

            self.username = cp[0]

            self.show_dashboard()



        def do_login(self) -> None:

            cp = self.credentials()

            if not cp:

                return

            sid = self.db.login(*cp)

            if sid is None:

                messagebox.showerror(

                    "Sign in failed", "Username or password is incorrect."

                )

                return

            self.student_id = sid

            self.username = cp[0]

            self.show_dashboard()



        # -- shell / navigation -----------------------------------------------



        def shell(self, title: str) -> tk.Frame:

            """Build top bar + nav and return a scrollable body frame."""

            self.clear()



            top = tk.Frame(self, bg=self.PANEL, padx=22, pady=15)

            top.pack(fill="x")

            self.label(top, "CYBERSAFE", 17, True, self.ACCENT).pack(side="left")

            self.label(top, title, 13, True).pack(side="left", padx=28)

            self.label(

                top, f"Student: {self.username}", 10, color=self.MUTED

            ).pack(side="right")



            nav = tk.Frame(self, bg=self.BG, padx=18, pady=12)

            nav.pack(fill="x")

            for t, fn in [

                ("Dashboard", self.show_dashboard),

                ("Take quiz", self.quiz_setup),

                ("Learning center", self.learning),

                ("Password tools", self.password_tools),

                ("My results", self.results),

            ]:

                self.button(nav, t, fn).pack(side="left", padx=4)

            self.button(nav, "Sign out", self.logout).pack(side="right")



            body_wrap = tk.Frame(self, bg=self.BG, padx=28, pady=18)

            body_wrap.pack(fill="both", expand=True)

            self.body = self._scrollable_body(body_wrap)

            return self.body



        def logout(self) -> None:

            self.student_id = None

            self.username = None

            self.show_auth()



        # -- dashboard --------------------------------------------------------



        def show_dashboard(self) -> None:

            self.shell("Student dashboard")

            rows = self.db.stats(self.student_id)

            avg = sum(r[3] for r in rows) / len(rows) if rows else 0

            best = max((r[3] for r in rows), default=0)



            self.label(self.body, f"Welcome back, {self.username}!", 25, True).pack(

                anchor="w"

            )

            self.label(

                self.body,

                "Build safer digital habits one short lesson at a time.",

                11,

                color=self.MUTED,

            ).pack(anchor="w", pady=(4, 20))



            cards = tk.Frame(self.body, bg=self.BG)

            cards.pack(fill="x")

            for title, val, sub in [

                ("QUIZZES COMPLETED", str(len(rows)), "Total attempts"),

                ("AVERAGE SCORE", f"{avg:.1f}%" if rows else "—", "Across your attempts"),

                ("PERSONAL BEST", f"{best:.1f}%" if rows else "—", "Highest score"),

            ]:

                c = self.card(cards)

                c.pack(side="left", fill="both", expand=True, padx=(0, 12))

                self.label(c, title, 9, True, self.MUTED).pack(anchor="w")

                self.label(c, val, 27, True, self.ACCENT).pack(anchor="w", pady=8)

                self.label(c, sub, 9, color=self.MUTED).pack(anchor="w")



            self.label(self.body, "Quick actions", 16, True).pack(

                anchor="w", pady=(28, 12)

            )

            row = tk.Frame(self.body, bg=self.BG)

            row.pack(anchor="w")

            self.button(row, "Start a cyber safety quiz", self.quiz_setup, True).pack(

                side="left", padx=(0, 10)

            )

            self.button(row, "Explore safety lessons", self.learning).pack(

                side="left", padx=10

            )

            self.button(row, "Check password strength", self.password_tools).pack(

                side="left", padx=10

            )



            self.label(self.body, "Latest activity", 15, True).pack(

                anchor="w", pady=(28, 10)

            )

            if not rows:

                self.label(

                    self.body,

                    "No quiz attempts yet. Take your first quiz to see your progress here.",

                    11,

                    color=self.MUTED,

                ).pack(anchor="w")

            else:

                for r in rows[:5]:

                    cat = r[0].replace("_", " ").title()

                    diff = (r[5] or "mixed").title() if len(r) > 5 else ""

                    self.label(

                        self.body,

                        f"{r[4][:16]}   •   {cat}   •   {r[1]}/{r[2]} correct   •   "

                        f"{r[3]:.1f}%   •   {diff}",

                        11,

                    ).pack(anchor="w", pady=3)



        # -- quiz -------------------------------------------------------------



        def quiz_setup(self) -> None:

            self.shell("Quiz setup")

            self.label(self.body, "Choose your challenge", 23, True).pack(

                anchor="w", pady=(0, 18)

            )



            self.label(self.body, "Quiz category", 11, True).pack(anchor="w")

            self.cat = ttk.Combobox(

                self.body,

                values=[

                    "Full quiz",

                    "Password safety",

                    "Phishing awareness",

                    "Online safety",

                ],

                state="readonly",

                width=30,

            )

            self.cat.current(0)

            self.cat.pack(anchor="w", pady=8, ipady=5)



            self.label(self.body, "Difficulty", 11, True).pack(anchor="w", pady=(14, 0))

            self.diff = ttk.Combobox(

                self.body,

                values=["Mixed", "Easy", "Medium", "Hard"],

                state="readonly",

                width=30,

            )

            self.diff.current(0)

            self.diff.pack(anchor="w", pady=8, ipady=5)



            self.label(

                self.body,

                "Hard mode may have fewer questions in some categories "

                "(the pool is smaller).",

                9,

                color=self.MUTED,

            ).pack(anchor="w", pady=(8, 0))



            self.button(self.body, "Begin quiz", self.start_quiz, True).pack(

                anchor="w", pady=20

            )



        def start_quiz(self) -> None:

            cats = {

                "Full quiz": core.FULL,

                "Password safety": "password",

                "Phishing awareness": "phishing",

                "Online safety": "online_safety",

            }

            self.category = cats[self.cat.get()]

            self.difficulty = (

                None if self.diff.get() == "Mixed" else self.diff.get().lower()

            )

            self.questions = core.select_questions(

                self.category, difficulty=self.difficulty

            )

            if not self.questions:

                messagebox.showwarning(

                    "No questions",

                    "No questions available for that category and difficulty. "

                    "Try Mixed or an easier level.",

                )

                return

            self.q_index = 0

            self.score = 0

            self.started = datetime.now()

            self.show_question()



        def show_question(self) -> None:

            self.shell("Quiz in progress")

            q = self.questions[self.q_index]

            text = q.get("question") or q.get("q", "")



            self.label(

                self.body,

                f"QUESTION {self.q_index + 1} OF {len(self.questions)}",

                10,

                True,

                self.ACCENT,

            ).pack(anchor="w")

            self.label(

                self.body,

                f"{q['category'].replace('_', ' ').title()}  •  {q['difficulty'].title()}",

                10,

                color=self.MUTED,

            ).pack(anchor="w", pady=5)

            self.label(self.body, text, 19, True).pack(anchor="w", pady=(18, 20))



            self.answer = tk.StringVar()

            opts = list(q["options"])

            secrets.SystemRandom().shuffle(opts)

            for opt in opts:

                tk.Radiobutton(

                    self.body,

                    text=opt,

                    variable=self.answer,

                    value=opt,

                    bg=self.BG,

                    fg=self.TEXT,

                    selectcolor=self.CARD,

                    activebackground=self.BG,

                    activeforeground=self.TEXT,

                    font=("Segoe UI", 12),

                    wraplength=850,

                    justify="left",

                ).pack(anchor="w", pady=8)



            self.button(self.body, "Submit answer", self.submit_answer, True).pack(

                anchor="w", pady=22

            )



        def submit_answer(self) -> None:

            chosen = self.answer.get()

            if not chosen:

                messagebox.showinfo("Choose an answer", "Select one option before continuing.")

                return



            q = self.questions[self.q_index]

            correct = chosen == q["answer"]

            self.score += int(correct)

            why = q.get("why", "")

            if correct:

                msg = f"Correct! {why}"

            else:

                msg = f"Not quite. Correct answer: {q['answer']}. {why}"

            messagebox.showinfo("Feedback", msg)



            self.q_index += 1

            if self.q_index < len(self.questions):

                self.show_question()

            else:

                self._finish_quiz()



        def _finish_quiz(self) -> None:

            total = len(self.questions)

            self.db.save_attempt(

                self.student_id,

                self.category,

                self.score,

                total,

                self.difficulty,

            )

            self.shell("Quiz results")

            pct = self.score / total * 100 if total else 0

            level = core.level_for(pct)



            self.label(self.body, "Quiz completed!", 24, True).pack(anchor="w", pady=10)

            self.label(

                self.body,

                f"{self.score} / {total} correct",

                30,

                True,

                self.ACCENT,

            ).pack(anchor="w", pady=8)

            self.label(

                self.body, f"Score: {pct:.1f}%     Level: {level}", 15, True

            ).pack(anchor="w", pady=8)



            tip = (

                "Great job — keep practising the harder topics."

                if pct >= 70

                else "Review the Learning Center tips and try the questions you missed."

            )

            self.label(self.body, tip, 11, color=self.MUTED).pack(anchor="w", pady=(8, 16))



            self.button(self.body, "Try another quiz", self.quiz_setup, True).pack(

                anchor="w", pady=8

            )

            self.button(self.body, "Back to dashboard", self.show_dashboard).pack(

                anchor="w"

            )



        # -- learning center --------------------------------------------------



        def learning(self) -> None:

            self.shell("Learning center")

            self.label(self.body, "Cyber Safety Learning Center", 23, True).pack(

                anchor="w", pady=(0, 16)

            )

            topics = [

                (

                    "Password safety",

                    "Use a unique, long password or passphrase for every account. "

                    "Enable multi-factor authentication and use a trusted password manager. "

                    "Never reuse passwords across important services.",

                ),

                (

                    "Phishing awareness",

                    "Pause before clicking. Check the sender and the real destination of links. "

                    "Never share one-time codes or passwords in response to unexpected messages. "

                    "When in doubt, contact the organisation through a known official channel.",

                ),

                (

                    "Online safety",

                    "Keep apps and the operating system updated. Review privacy settings regularly. "

                    "Avoid oversharing personal information and report suspicious or harmful contact "

                    "to a trusted adult or the platform.",

                ),

            ]

            for title, desc in topics:

                c = self.card(self.body)

                c.pack(fill="x", pady=7)

                self.label(c, title, 15, True, self.ACCENT).pack(anchor="w")

                self.label(c, desc, 11).pack(anchor="w", pady=(7, 0))



        # -- password tools ---------------------------------------------------



        def password_tools(self) -> None:

            self.shell("Password safety tools")



            self.label(self.body, "Password strength checker", 22, True).pack(

                anchor="w", pady=(0, 8)

            )

            self.label(

                self.body,

                "Analysis happens locally. The password is never saved.",

                10,

                color=self.MUTED,

            ).pack(anchor="w")



            self.pass_entry = tk.Entry(

                self.body,

                width=48,

                show="•",

                font=("Segoe UI", 13),

                bg=self.CARD,

                fg=self.TEXT,

                insertbackground=self.TEXT,

                relief="flat",

            )

            self.pass_entry.pack(anchor="w", ipady=10, pady=12)



            btn_row = tk.Frame(self.body, bg=self.BG)

            btn_row.pack(anchor="w")

            self.button(btn_row, "Check strength", self.check_password, True).pack(

                side="left", padx=(0, 8)

            )

            self.button(btn_row, "Generate secure password", self.generate_pw).pack(

                side="left", padx=4

            )

            self.button(btn_row, "Generate passphrase", self.generate_passphrase).pack(

                side="left", padx=4

            )



            self.pw_result = tk.Label(

                self.body,

                text="",

                bg=self.BG,

                fg=self.TEXT,

                font=("Segoe UI", 12),

                justify="left",

                wraplength=850,

            )

            self.pw_result.pack(anchor="w", pady=16)



            self.label(

                self.body,

                "Tip: A 6+ word passphrase from a large word list is usually stronger "

                "and easier to remember than a short complex password.",

                9,

                color=self.MUTED,

            ).pack(anchor="w", pady=(4, 0))



        def check_password(self) -> None:

            pw = self.pass_entry.get()

            if not pw:

                self.pw_result.config(text="Enter a password to check.")

                return

            res = core.evaluate_password(pw)

            lines = [f"Strength: {res['label']} ({res['score']}/100)"]

            if res.get("bits") is not None:

                lines.append(f"Rough entropy estimate: {res['bits']:.1f} bits")

            lines.extend(f"• {x}" for x in res["feedback"])

            self.pw_result.config(text="\n".join(lines))



        def generate_pw(self) -> None:

            pw = core.generate_password()

            self.pass_entry.delete(0, "end")

            self.pass_entry.insert(0, pw)

            # Temporarily show it so the user can copy

            self.pass_entry.config(show="")

            self.pw_result.config(

                text=(

                    "A new random password was generated locally.\n"

                    "Copy it into a password manager, then clear this field.\n"

                    "Click “Check strength” if you want to see its rating."

                )

            )

            self.after(12_000, lambda: self.pass_entry.config(show="•"))



        def generate_passphrase(self) -> None:

            phrase = core.generate_passphrase(words=6)

            self.pass_entry.delete(0, "end")

            self.pass_entry.insert(0, phrase)

            self.pass_entry.config(show="")

            bits = core.passphrase_bits(6)

            self.pw_result.config(

                text=(

                    f"Passphrase generated (6 words, ~{bits:.0f} bits of entropy).\n"

                    "Copy it into a password manager. Click “Check strength” for feedback."

                )

            )

            self.after(12_000, lambda: self.pass_entry.config(show="•"))



        # -- results ----------------------------------------------------------



        def results(self) -> None:

            self.shell("My results")

            self.label(self.body, "Your quiz history", 23, True).pack(

                anchor="w", pady=(0, 16)

            )

            rows = self.db.stats(self.student_id)

            if not rows:

                self.label(

                    self.body,

                    "No results yet. Complete a quiz to build your history.",

                    11,

                    color=self.MUTED,

                ).pack(anchor="w")

                return



            for r in rows:

                cat = r[0].replace("_", " ").title()

                diff = (r[5] or "mixed").title() if len(r) > 5 else "—"

                status = "Strong" if r[3] >= 80 else "Keep practising"

                c = self.card(self.body)

                c.pack(fill="x", pady=5)

                self.label(c, f"{cat}  |  {r[4][:16]}  |  {diff}", 11, True).pack(

                    anchor="w"

                )

                self.label(

                    c,

                    f"{r[1]}/{r[2]} correct  •  {r[3]:.1f}%  •  {status}",

                    10,

                    color=self.ACCENT,

                ).pack(anchor="w", pady=(5, 0))



        # -- cleanup ----------------------------------------------------------



        def _on_close(self) -> None:

            try:

                self.db.close()

            except Exception:

                pass

            self.destroy()



        def destroy(self) -> None:

            try:

                self.db.close()

            except Exception:

                pass

            super().destroy()





if __name__ == "__main__":
    if not HAS_TK:
        raise SystemExit(
            "tkinter is required for the GUI. On Debian/Ubuntu: sudo apt install python3-tk"
        )
    CyberSafetyGUI().mainloop()
