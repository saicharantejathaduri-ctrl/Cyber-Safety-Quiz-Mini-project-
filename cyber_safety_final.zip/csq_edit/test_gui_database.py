"""Tests for the graphical app's SQLite account and attempt storage.

Also verifies question-key compatibility between core and GUI.
"""
from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from gui_app import Database


class DatabaseTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.db = Database(Path(self.tmp.name) / "test.db")

    def tearDown(self) -> None:
        self.db.close()
        self.tmp.cleanup()

    def test_register_and_login(self) -> None:
        sid = self.db.register("student_1", "safe-password-123")
        self.assertIsNotNone(sid)
        self.assertEqual(self.db.login("student_1", "safe-password-123"), sid)
        self.assertIsNone(self.db.login("student_1", "wrong-password"))

    def test_duplicate_username_rejected(self) -> None:
        self.assertIsNotNone(self.db.register("learner", "safe-password-123"))
        self.assertIsNone(self.db.register("learner", "another-password"))

    def test_attempt_history(self) -> None:
        sid = self.db.register("learner", "safe-password-123")
        self.db.save_attempt(sid, "phishing", 5, 6, "easy")
        rows = self.db.stats(sid)
        self.assertEqual(len(rows), 1)
        # category, correct, total, percent, created_at, difficulty
        self.assertEqual(rows[0][0], "phishing")
        self.assertEqual((rows[0][1], rows[0][2], rows[0][3]), (5, 6, 83.3))
        self.assertEqual(rows[0][5], "easy")

    def test_multiple_attempts_ordered_newest_first(self) -> None:
        sid = self.db.register("learner", "safe-password-123")
        self.db.save_attempt(sid, "password", 4, 6, "medium")
        self.db.save_attempt(sid, "full", 10, 12, "mixed")
        rows = self.db.stats(sid)
        self.assertEqual(len(rows), 2)
        self.assertEqual(rows[0][0], "full")  # newest first
        self.assertEqual(rows[1][0], "password")

    def test_login_unknown_user(self) -> None:
        self.assertIsNone(self.db.login("nobody", "anything-long-enough"))

    def test_zero_total_attempt_safe(self) -> None:
        sid = self.db.register("edge", "safe-password-123")
        # Should not raise; percent becomes 0.0
        self.db.save_attempt(sid, "password", 0, 0, None)
        rows = self.db.stats(sid)
        self.assertEqual(rows[0][3], 0.0)
        self.assertEqual(rows[0][5], "mixed")


class QuestionKeyCompatibilityTests(unittest.TestCase):
    """Ensure the core question bank exposes both 'q' and 'question' keys."""

    def test_question_alias_present(self) -> None:
        import cyber_safety_quiz as core

        self.assertGreaterEqual(len(core.QUESTIONS), 40)
        for q in core.QUESTIONS:
            self.assertIn("q", q)
            self.assertIn("question", q)
            self.assertEqual(q["q"], q["question"])
            self.assertIn("answer", q)
            self.assertIn("options", q)
            self.assertIn(q["answer"], q["options"])

    def test_select_questions_preserves_keys(self) -> None:
        import cyber_safety_quiz as core

        selected = core.select_questions("password", difficulty="easy")
        self.assertTrue(selected)
        for q in selected:
            self.assertEqual(q["q"], q["question"])


if __name__ == "__main__":
    unittest.main()
