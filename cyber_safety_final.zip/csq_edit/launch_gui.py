"""Launch the Cyber Safety Quiz graphical desktop application."""
from gui_app import CyberSafetyGUI

if __name__ == '__main__':
    CyberSafetyGUI().mainloop()
