#!/usr/bin/env python3
"""Cyber Safety Quiz - SmartCommunity Hack Project #75.

Single-file, menu-driven terminal app (Python 3.10+, standard library only).
Run:  python cyber_safety_quiz.py
Help: python cyber_safety_quiz.py --help   (--demo, --stats, --export, --data FILE ...)
"""
from __future__ import annotations

import argparse
import csv
import getpass
import json
import math
import os
import random
import re
import secrets
import statistics
import sys
import time
from collections import Counter, defaultdict
from dataclasses import dataclass, asdict, fields
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

__version__ = "2.1.0"


# ======================================================================
# UI
# ======================================================================
USE_COLOR = sys.stdout.isatty() and "NO_COLOR" not in os.environ
if USE_COLOR and os.name == "nt":
    os.system("")  # enables ANSI escape codes on Windows terminals

_UTF8 = (getattr(sys.stdout, "encoding", "") or "").lower().replace("-", "") == "utf8"


def _c(code, text):
    return f"\033[{code}m{text}\033[0m" if USE_COLOR else str(text)


def bold(t): return _c("1", t)
def dim(t): return _c("2", t)
def red(t): return _c("31", t)
def green(t): return _c("32", t)
def yellow(t): return _c("33", t)
def cyan(t): return _c("36", t)


def banner():
    w = 56
    lines = ["", "CYBER SAFETY QUIZ", "Test your password, phishing & online safety skills", ""]
    print(cyan("+" + "=" * w + "+"))
    for ln in lines:
        print(cyan("|") + bold(ln.center(w)) + cyan("|"))
    print(cyan("+" + "=" * w + "+"))


def header(title):
    print("\n" + bold(cyan(f"== {title} ==")))


def bar(pct, width=20, ascii_only=False):
    filled = round(max(0, min(100, pct)) / 100 * width)
    full, empty = ("#", "-") if (ascii_only or not _UTF8) else ("█", "░")
    return full * filled + empty * (width - filled)


def colour_pct(pct, text=None):
    text = text if text is not None else f"{pct:.1f}%"
    if pct >= 70:
        return green(text)
    if pct >= 50:
        return yellow(text)
    return red(text)


def truncate(s, w):
    s = str(s)
    return s if len(s) <= w else s[: w - 1] + "~"


COLS = [("ID", 4), ("Date", 16), ("Player", 16), ("Category", 14),
        ("Score", 7), ("Pct", 6), ("Level", 14), ("Time", 6)]


def table_lines(records):
    """Fixed-width table (plain text, no colour) for a list of QuizRecords."""
    head = " | ".join(n.ljust(w) for n, w in COLS)
    sep = "-+-".join("-" * w for _, w in COLS)
    lines = [head, sep]
    for r in records:
        cat = {"password": "Password", "phishing": "Phishing",
               "online_safety": "Online Safety", "full": "Full Quiz"}.get(r.category, r.category)
        dur = f"{int(r.duration_sec)}s" if r.duration_sec else "-"
        cells = [str(r.id), r.timestamp.replace("T", " ")[:16], r.player, cat,
                 f"{r.correct}/{r.total}", f"{r.percent:.0f}%", r.level, dur]
        lines.append(" | ".join(truncate(c, w).ljust(w) for c, (_, w) in zip(cells, COLS)))
    return lines


def paginate(records, page_size=10, title="Records"):
    """Show a table page by page."""
    if not records:
        print(yellow("  No records to show."))
        return
    pages = (len(records) + page_size - 1) // page_size
    for p in range(pages):
        chunk = records[p * page_size:(p + 1) * page_size]
        header(f"{title} (page {p + 1}/{pages}, {len(records)} total)")
        for ln in table_lines(chunk):
            print("  " + ln)
        if p < pages - 1:
            if input(dim("  [Enter] next page, [q] stop: ")).strip().lower() == "q":
                break


# ======================================================================
# VALIDATION
# ======================================================================
NAME_RE = re.compile(r"^[A-Za-z][A-Za-z .'-]{1,29}$")


def clean_name(raw):
    """Return a tidy player name, or None if it does not meet the rules."""
    if raw is None:
        return None
    s = " ".join(str(raw).split())
    return s if NAME_RE.match(s) else None


def ask(prompt, parse):
    """Prompt until `parse(text)` stops raising ValueError."""
    while True:
        raw = input(prompt).strip()
        try:
            return parse(raw)
        except ValueError as exc:
            print(red(f"  x {exc}"))


def ask_int(prompt, lo, hi):
    def parse(s):
        if not s:
            raise ValueError("Input cannot be blank.")
        try:
            n = int(s)
        except ValueError:
            raise ValueError(f"'{s}' is not a whole number.") from None
        if not lo <= n <= hi:
            raise ValueError(f"Enter a number between {lo} and {hi}.")
        return n
    return ask(prompt, parse)


def ask_optional_int(prompt, lo, hi):
    """Blank -> None, otherwise a validated int."""
    def parse(s):
        if not s:
            return None
        try:
            n = int(s)
        except ValueError:
            raise ValueError(f"'{s}' is not a whole number.") from None
        if not lo <= n <= hi:
            raise ValueError(f"Enter a number between {lo} and {hi} (or leave blank).")
        return n
    return ask(prompt, parse)


def ask_name(prompt, default=None):
    def parse(s):
        if not s and default:
            return default
        name = clean_name(s)
        if not name:
            raise ValueError("Use 2-30 characters: letters, spaces, . ' - (start with a letter).")
        return name
    return ask(prompt, parse)


def ask_yes_no(prompt, default=None):
    def parse(s):
        s = s.lower()
        if not s and default is not None:
            return default
        if s in ("y", "yes"):
            return True
        if s in ("n", "no"):
            return False
        raise ValueError("Please answer y or n.")
    return ask(prompt, parse)


def ask_text(prompt):
    return input(prompt).strip()


# ======================================================================
# MODELS
# ======================================================================
CATEGORIES = {
    "password": "Password Safety",
    "phishing": "Phishing Awareness",
    "online_safety": "Online Safety",
}
FULL = "full"
VALID_CATEGORIES = list(CATEGORIES) + [FULL]
CATEGORY_LABELS = {**CATEGORIES, FULL: "Full Quiz"}
CATEGORY_ALIASES = {"pw": "password", "passwords": "password", "phish": "phishing",
                    "safety": "online_safety", "online": "online_safety",
                    "all": "full", "full_quiz": "full"}

LEVELS = [(90, "Cyber Guardian"), (70, "Safe Surfer"), (50, "Getting There"), (0, "At Risk")]


def level_for(percent: float) -> str:
    for threshold, name in LEVELS:
        if percent >= threshold:
            return name
    return LEVELS[-1][1]


def make_percent(correct: int, total: int) -> float:
    return round(correct / total * 100, 1)


def _to_int(value, name, lo=0, hi=None):
    s = str(value).strip() if value is not None else ""
    if s == "":
        raise ValueError(f"{name} is missing")
    try:
        n = int(s)
    except ValueError:
        try:
            f = float(s)
        except ValueError:
            raise ValueError(f"{name} must be a whole number (got '{s}')") from None
        if not f.is_integer():
            raise ValueError(f"{name} must be a whole number (got '{s}')")
        n = int(f)
    if n < lo or (hi is not None and n > hi):
        raise ValueError(f"{name} out of range (got {n}, allowed {lo}-{hi if hi is not None else 'inf'})")
    return n


@dataclass
class QuizRecord:
    id: int
    timestamp: str
    player: str
    category: str
    correct: int
    total: int
    percent: float
    level: str
    duration_sec: float
    # Optional per-category breakdown (only used by "full" quizzes)
    password_correct: Optional[int] = None
    password_total: Optional[int] = None
    phishing_correct: Optional[int] = None
    phishing_total: Optional[int] = None
    online_safety_correct: Optional[int] = None
    online_safety_total: Optional[int] = None

    @classmethod
    def from_dict(cls, d: dict) -> "QuizRecord":
        """Validate and normalise a raw dict. Raises ValueError on bad data."""
        player = clean_name(d.get("player"))
        if not player:
            raise ValueError("invalid player name")
        cat = str(d.get("category", "")).strip().lower().replace(" ", "_").replace("-", "_")
        cat = CATEGORY_ALIASES.get(cat, cat)
        if cat not in VALID_CATEGORIES:
            raise ValueError(f"unknown category '{d.get('category')}'")
        total = _to_int(d.get("total"), "total", 1, 100)
        correct = _to_int(d.get("correct"), "correct", 0, total)

        ts_raw = str(d.get("timestamp") or "").strip()
        try:
            if ts_raw.endswith(("Z", "z")):  # Python 3.10 cannot parse a trailing Z
                ts_raw = ts_raw[:-1] + "+00:00"
            ts = datetime.fromisoformat(ts_raw) if ts_raw else datetime.now()
        except ValueError:
            raise ValueError(f"bad timestamp '{ts_raw}' (use YYYY-MM-DD or YYYY-MM-DDTHH:MM:SS)") from None
        if ts.tzinfo is not None:  # store everything as naive local time so dates compare safely
            ts = ts.astimezone().replace(tzinfo=None)
        if ts > datetime.now() + timedelta(days=1):
            raise ValueError(f"timestamp '{ts_raw}' is in the future")

        dur_raw = str(d.get("duration_sec") or "").strip()
        try:
            dur = float(dur_raw) if dur_raw else 0.0
        except ValueError:
            raise ValueError(f"bad duration_sec '{dur_raw}'") from None
        if not 0 <= dur <= 86400:
            raise ValueError("duration_sec must be between 0 and 86400")

        rec_id = _to_int(d.get("id") or 0, "id", 0)
        pct = make_percent(correct, total)
        rec = cls(rec_id, ts.isoformat(timespec="seconds"), player, cat, correct, total,
                  pct, level_for(pct), round(dur, 1))

        if cat == FULL:
            bc = bt = 0
            for key in CATEGORIES:
                c, t = d.get(f"{key}_correct"), d.get(f"{key}_total")
                blank_c, blank_t = str(c or "").strip() == "", str(t or "").strip() == ""
                if blank_c and blank_t:
                    continue
                if blank_c or blank_t:
                    raise ValueError(f"{key} breakdown is incomplete")
                t = _to_int(t, f"{key}_total", 1, 100)
                c = _to_int(c, f"{key}_correct", 0, t)
                setattr(rec, f"{key}_correct", c)
                setattr(rec, f"{key}_total", t)
                bc, bt = bc + c, bt + t
            if bt and (bc != correct or bt != total):
                raise ValueError("category breakdown does not add up to totals")
        return rec

    def to_dict(self) -> dict:
        return asdict(self)

    def breakdown(self) -> dict:
        """{category: (correct, total)} for whatever is known."""
        if self.category != FULL:
            return {self.category: (self.correct, self.total)}
        out = {}
        for key in CATEGORIES:
            c, t = getattr(self, f"{key}_correct"), getattr(self, f"{key}_total")
            if c is not None and t:
                out[key] = (c, t)
        return out


CSV_FIELDS = [f.name for f in fields(QuizRecord)]


# ======================================================================
# QUIZ DATA
# ======================================================================
DIFFICULTIES = ("easy", "medium", "hard")


def _q(category, question, correct, wrong, why, difficulty="medium"):
    """Build a question. The correct answer is stored explicitly in "answer".

    Both "q" and "question" keys are set so GUI and terminal share the same shape.
    """
    assert difficulty in DIFFICULTIES and category in CATEGORIES
    return {
        "category": category,
        "q": question,
        "question": question,  # alias for GUI / external consumers
        "answer": correct,
        "difficulty": difficulty,
        "options": [correct, *wrong],
        "why": why,
    }


QUESTIONS = [
    # ---------------- PASSWORD ----------------
    _q("password",
       "Which of these is the strongest password?",
       "correct-horse-battery-staple-92",
       ["P@ssw0rd1", "Summer2024!", "qwerty123456"],
       "Length and unpredictability beat clever substitutions. A long passphrase is hard to guess and easy to remember.",
       "easy"),
    _q("password",
       "What is the safest way to handle dozens of different passwords?",
       "Use a reputable password manager",
       ["Reuse one strong password everywhere", "Write them in a text file named passwords.txt", "Use your pet's name plus a number"],
       "A password manager lets you use unique, random passwords for every account without memorising them.",
       "easy"),
    _q("password",
       "What does multi-factor authentication (MFA) add to your login?",
       "A second proof of identity besides the password",
       ["A longer password requirement", "Automatic password changes", "Protection only against forgotten passwords"],
       "Even if a password leaks, an attacker still needs your second factor (app code, security key, etc.).",
       "easy"),
    _q("password",
       "You learn your password appeared in a data breach. What should you do first?",
       "Change it everywhere it was used and enable MFA",
       ["Nothing - breaches are old news", "Add a '1' to the end of it", "Delete your email account"],
       "Attackers try leaked passwords on other sites (credential stuffing), so change it everywhere it was reused.",
       "medium"),
    _q("password",
       "A caller claiming to be IT support asks for your password to 'fix your account'. You should:",
       "Refuse - legitimate staff never ask for your password",
       ["Give it, they sound professional", "Give only half of it", "Send it by text so it is on record"],
       "No genuine support team needs your password. This is a classic social-engineering tactic.",
       "easy"),
    _q("password",
       "How many different sites should share the same password?",
       "None - every account gets a unique password",
       ["Two or three low-risk ones", "All of them, if it is strong", "Only social media accounts"],
       "One breach would otherwise unlock every account that shares the password.",
       "easy"),
    _q("password",
       "Which MFA method is generally the most resistant to phishing?",
       "A hardware security key or passkey",
       ["A code sent by SMS", "A security question such as your mother's maiden name", "A second password that you also reuse elsewhere"],
       "Security keys and passkeys are bound to the real website, so they cannot be handed over to a look-alike site.",
       "hard"),
    _q("password",
       "What is the safest way to answer 'security questions' on an account?",
       "Use a random answer and store it in your password manager",
       ["Give your real mother's maiden name", "Use your pet's name from your public posts", "Use the name of your school"],
       "Real answers are often easy to find online. A random answer cannot be guessed or researched.",
       "hard"),
    _q("password",
       "A colleague needs temporary access to a shared account. The best approach is to:",
       "Use the service's sharing feature or a password manager's secure share",
       ["Email them the password", "Post it in the team chat", "Write it on a sticky note on their monitor"],
       "Built-in sharing keeps access controlled and revocable, and avoids passwords sitting in inboxes and chat logs.",
       "medium"),
    _q("password",
       "Your browser offers to save a password on a shared library computer. You should:",
       "Decline, and log out when you finish",
       ["Accept so it is quicker next time", "Accept but use a short password", "Leave the page open so you stay logged in"],
       "Saved passwords and open sessions on shared machines give the next person access to your accounts.",
       "medium"),
    _q("password",
       "Which describes a good master password for your password manager?",
       "A long, unique passphrase that you never use anywhere else",
       ["Your usual email password, so you remember it", "A short password with lots of symbols", "Your name and birth year"],
       "The master password protects everything else, so it must be long, unique and never reused.",
       "medium"),
    _q("password",
       "What is 'credential stuffing'?",
       "Trying leaked username and password pairs on other websites",
       ["Guessing a password one character at a time", "Filling a browser with too many saved logins", "Tricking someone into revealing a password by phone"],
       "Because people reuse passwords, attackers replay breached logins across many sites automatically.",
       "medium"),
    _q("password",
       "When you enable MFA, the service gives you backup recovery codes. Where should you keep them?",
       "Offline in a safe place, or inside your password manager",
       ["In a screenshot in your public photo album", "In an email to yourself with the subject 'codes'", "Nowhere - you will never need them"],
       "Recovery codes get you back into the account if you lose your phone, so protect them like passwords.",
       "medium"),
    _q("password",
       "When should you change a strong, unique password?",
       "When there is a reason: a breach, suspected compromise or shared access",
       ["Every week, without exception", "Every day, to be safe", "Never, even after a breach"],
       "Forced frequent changes lead to weak, predictable passwords. Change them when there is a reason to.",
       "hard"),
    _q("password",
       "Your phone shows an MFA approval request that you did not trigger. You should:",
       "Deny it and change your password immediately",
       ["Approve it so the notifications stop", "Ignore it and do nothing", "Restart your phone and approve the next one"],
       "An unexpected prompt means someone already has your password. Attackers spam prompts hoping you approve one ('MFA fatigue').",
       "hard"),

    # ---------------- PHISHING ----------------
    _q("phishing",
       "An email from 'your bank' says your account will be locked in 1 hour unless you click a link. Best response?",
       "Ignore the link and log in via the bank's official site or app",
       ["Click quickly to avoid lockout", "Reply asking if it is real", "Forward it to all your friends as a warning"],
       "Artificial urgency is a phishing hallmark. Go to the official site yourself instead of using the link.",
       "easy"),
    _q("phishing",
       "Which web address is most likely a phishing site?",
       "paypa1-secure-login.com",
       ["paypal.com", "www.paypal.com/signin", "accounts.paypal.com"],
       "Look-alike domains swap characters (the digit 1 for the letter l) or add words like 'secure-login'.",
       "medium"),
    _q("phishing",
       "You receive an unexpected 'invoice.zip' from someone you don't know. You should:",
       "Not open it and report/delete the email",
       ["Open it to see what it is", "Open it on your phone instead", "Extract it but not run anything"],
       "Unexpected attachments are a top malware delivery method. Report and delete.",
       "easy"),
    _q("phishing",
       "An SMS says a parcel fee is unpaid and includes a short link. This is probably:",
       "Smishing (SMS phishing) - don't tap the link",
       ["A normal courier notice", "Safe if the number looks local", "Only dangerous on Android"],
       "Fake delivery texts are widespread. Check the courier's official app or website directly.",
       "medium"),
    _q("phishing",
       "Which is a common red flag of a phishing email?",
       "Generic greeting, urgency and a mismatched sender domain",
       ["A personalised greeting with your full name", "A company logo in the footer", "Perfect spelling and grammar"],
       "Generic greetings, pressure, and a sender domain that doesn't match the organisation are classic signs.",
       "easy"),
    _q("phishing",
       "You clicked a phishing link and typed in your password. What now?",
       "Change the password, enable MFA and report it",
       ["Hope nothing happens", "Just clear your browser history", "Wait a week and see"],
       "Act fast: change the password (and any reused ones), turn on MFA, check account activity and report it.",
       "medium"),
    _q("phishing",
       "The text of a link in an email shows one address, but hovering over it reveals another. This means:",
       "The link may be deceptive - do not click it",
       ["It is just a formatting quirk", "The email is safer because it uses a tracking link", "Your mouse is faulty"],
       "Attackers disguise the real destination behind friendly-looking text. Always check where a link really goes.",
       "medium"),
    _q("phishing",
       "Your 'CEO' emails urgently asking you to buy gift cards and send the codes. This is most likely:",
       "CEO fraud - verify through a separate, trusted channel",
       ["A normal request you should complete quickly", "Fine if the display name matches", "Fine if the amount is small"],
       "Business email compromise relies on authority and urgency. Confirm by phone or in person before acting.",
       "hard"),
    _q("phishing",
       "What is 'spear phishing'?",
       "A targeted attack that uses personal details about the victim",
       ["Phishing that only happens by phone", "Mass spam with random content", "Phishing aimed only at fishing websites"],
       "Spear phishing is tailored using information from social media or earlier breaches, which makes it more convincing.",
       "hard"),
    _q("phishing",
       "A QR code sticker on a parking meter leads to a payment page. What is the wise move?",
       "Check the sticker is not covering the original and use the official app",
       ["Scan any QR code that has a logo on it", "Trust it, because QR codes are only images", "Enter your card details as quickly as possible"],
       "'Quishing' replaces genuine QR codes with fake ones. Paying through the official app avoids the risk.",
       "hard"),
    _q("phishing",
       "What is 'vishing'?",
       "Phishing carried out through phone calls or voicemail",
       ["Phishing that only happens in video games", "A virus that spreads through voice assistants", "Phishing carried out only by post"],
       "Callers pretend to be banks, tech support or officials to pressure you into revealing details or sending money.",
       "easy"),
    _q("phishing",
       "A 'password expiry' email with a login button arrives at your work address. The safest check is to:",
       "Open the company portal by typing its address yourself, or ask IT",
       ["Click the button and log in quickly", "Reply with your old password to confirm", "Forward it to colleagues to see what they think"],
       "Never log in through a link in an unexpected email. Go to the real site yourself or check with IT.",
       "medium"),
    _q("phishing",
       "An email has a '.html' attachment claiming to be a voice message. This is most likely:",
       "A fake login page designed to harvest your credentials",
       ["A harmless audio file", "A normal calendar invite", "A software update from your phone maker"],
       "HTML attachments can show a convincing fake sign-in page offline, which helps them slip past mail filters.",
       "hard"),
    _q("phishing",
       "Which is a classic sign of a fake job offer?",
       "You are asked to pay a fee or share bank or ID details before starting",
       ["The employer interviews you by video", "The offer includes a written contract", "The company has an official website"],
       "Real employers don't charge you to work for them. Requests for fees or early ID documents point to fraud.",
       "easy"),
    _q("phishing",
       "A search ad shows a link that looks exactly like your bank's login page. A safer habit is to:",
       "Use a saved bookmark or the official app instead of search ads",
       ["Click the first result because it is at the top", "Trust it if it has a padlock", "Enter your details and check the address afterwards"],
       "Scammers buy ads that imitate banks. Bookmarks and official apps skip the search step altogether.",
       "hard"),

    # ---------------- ONLINE SAFETY ----------------
    _q("online_safety",
       "You need to check your bank balance while on cafe public Wi-Fi. The safest option is:",
       "Use mobile data or a trusted VPN",
       ["Use the Wi-Fi - the password protects it", "Use any open network, but only briefly", "Turn off your screen lock first"],
       "Shared networks can be monitored or spoofed. Mobile data or a VPN reduces the risk.",
       "medium"),
    _q("online_safety",
       "Why should you install software updates promptly?",
       "They patch security holes attackers exploit",
       ["They only change the app's look", "They make the device slower on purpose", "They are optional marketing"],
       "Many attacks target known flaws that updates have already fixed.",
       "easy"),
    _q("online_safety",
       "Which of these is the riskiest to post publicly on social media?",
       "Your home address, birth date and travel dates",
       ["A photo of your lunch", "A favourite song", "A public book review"],
       "Personal details help attackers guess security answers, steal identities or know when you're away.",
       "easy"),
    _q("online_safety",
       "The browser shows a padlock (HTTPS) on a website. What does it guarantee?",
       "The connection is encrypted - not that the site is trustworthy",
       ["The site is legitimate and safe", "The site has no malware", "The owner is verified by the government"],
       "Phishing sites can use HTTPS too. The padlock protects data in transit, not the site's honesty.",
       "hard"),
    _q("online_safety",
       "You find a USB drive in the car park. What should you do?",
       "Not plug it in - hand it to IT/security",
       ["Plug it in to find the owner", "Plug it into an old laptop", "Format it and keep it"],
       "Dropped USB sticks are a known attack vector and can run malicious code automatically.",
       "medium"),
    _q("online_safety",
       "Someone online keeps sending you threatening or scam messages. A good response is:",
       "Don't engage - block, save evidence and report",
       ["Reply angrily so they stop", "Send them your details to 'verify' you", "Delete everything and say nothing to anyone"],
       "Engaging can escalate things. Keep screenshots and report to the platform, school/employer or police.",
       "medium"),
    _q("online_safety",
       "What should you do before selling or recycling an old phone?",
       "Back it up, sign out of your accounts and factory reset it",
       ["Just delete your photos", "Remove the SIM card only", "Nothing - the data erases itself"],
       "A proper reset, after signing out of accounts, prevents the next owner from recovering your data.",
       "medium"),
    _q("online_safety",
       "An app asks for access to your contacts and microphone for no clear reason. You should:",
       "Deny the permission, or skip the app if it truly needs it",
       ["Allow every permission without reading", "Allow it - apps never misuse permissions", "Allow it now and forget about it"],
       "Apps should only get the permissions they need. Over-broad access is a privacy and security risk.",
       "medium"),
    _q("online_safety",
       "You get a friend request from a brand-new profile with no mutual friends. Best action:",
       "Ignore or report it - do not accept unknown accounts",
       ["Accept - more followers is better", "Accept and send them your phone number", "Accept just to look at their profile"],
       "Fake profiles are used for scams, catfishing and gathering personal information.",
       "easy"),
    _q("online_safety",
       "Which backup approach best protects you against ransomware?",
       "Regular backups, including one offline or off-site copy",
       ["A single copy on the same computer", "A network drive that is always connected", "No backup, because you have antivirus"],
       "Ransomware can encrypt connected drives too. An offline or off-site copy lets you restore without paying.",
       "hard"),
    _q("online_safety",
       "Which threat does a VPN NOT protect you from?",
       "Clicking a phishing link or installing malware yourself",
       ["Someone snooping on your traffic over public Wi-Fi", "Your internet provider seeing which sites you visit", "Your location being obvious from your IP address"],
       "A VPN encrypts your connection, but it cannot stop you from handing over details or running malicious files.",
       "hard"),
    _q("online_safety",
       "What is the safest way to install a phone app?",
       "From the official app store, after checking the publisher and reviews",
       ["From a link sent in a text message", "From any website offering it free", "From a file a stranger shared in a chat"],
       "Official stores scan apps and can remove malicious ones. Sideloaded apps skip those protections.",
       "easy"),
    _q("online_safety",
       "Which phone lock setup is best?",
       "A PIN or biometric, with auto-lock after a short time",
       ["No lock, so you can open it quickly", "A simple swipe pattern that anyone can see", "A lock that only activates after 30 minutes"],
       "A lock stops a thief or snoop from reaching your accounts, photos and saved logins.",
       "easy"),
    _q("online_safety",
       "A friend's account suddenly sends you an odd message with a file link. You should:",
       "Contact your friend through another channel before opening it",
       ["Open it right away because it is from a friend", "Share it with others to ask what it is", "Reply asking them to resend it"],
       "Hacked accounts spread malware and scams to contacts. Verify through a different channel first.",
       "medium"),
    _q("online_safety",
       "Which is a sign that your social media account may be hacked?",
       "Posts or messages you didn't write, or login alerts from unknown places",
       ["Slightly fewer likes than usual", "A new app version being available", "A friend changing their profile picture"],
       "Unfamiliar activity and unexpected login alerts are the clearest signs. Change your password, enable MFA and log out other sessions.",
       "medium"),
]


# ======================================================================
# ENGINE
# ======================================================================
def select_questions(category, rng=random, per_category=4, per_single=6, difficulty=None):
    """Full quiz = `per_category` random questions from each category.

    A single-category quiz draws `per_single` random questions from that
    category's pool, so repeat attempts see different questions.
    `difficulty` ("easy" / "medium" / "hard" / None for mixed) narrows the pool.
    """
    def pool_for(key):
        return [q for q in QUESTIONS
                if q["category"] == key and (difficulty is None or q["difficulty"] == difficulty)]

    if category == FULL:
        chosen = []
        for key in CATEGORIES:
            pool = pool_for(key)
            chosen += rng.sample(pool, min(per_category, len(pool)))
        rng.shuffle(chosen)
        return chosen
    pool = pool_for(category)
    return rng.sample(pool, min(per_single, len(pool)))


def shuffled(question, rng=random):
    """Return (options, index_of_correct_option) with options in random order."""
    options = list(question["options"])
    correct_text = question["answer"]
    rng.shuffle(options)
    return options, options.index(correct_text)


def grade(correct, total):
    pct = make_percent(correct, total)
    return pct, level_for(pct)


# ---------------------------------------------------------------- passwords
COMMON = ["password", "qwerty", "letmein", "welcome", "admin", "iloveyou", "monkey",
          "dragon", "football", "abc123", "123456", "login", "master", "sunshine",
          "princess", "baseball", "trustno1", "shadow", "superman", "summer", "winter",
          "12345678", "111111", "000000", "charlie", "michael", "jessica", "ashley", "hunter",
          "freedom", "whatever", "starwars", "batman", "cheese", "pokemon", "computer", "internet",
          "soccer", "hello", "secret", "flower", "iloveu", "qazwsx", "changeme", "default"]
LEET = str.maketrans({"@": "a", "0": "o", "3": "e", "$": "s", "5": "s", "7": "t"})


def _common_hits(pw):
    """Common words found in `pw`, also catching leetspeak (p@ssw0rd, l0gin...)."""
    base = pw.lower().translate(LEET)
    variants = {base.replace("1", "i"), base.replace("1", "l")}
    return sorted({w for w in COMMON for v in variants if w in v}, key=len, reverse=True)
SEQUENCES = ["abcdefghijklmnopqrstuvwxyz", "0123456789", "qwertyuiop", "asdfghjkl", "zxcvbnm"]


def _has_sequence(pw, n=4):
    low = pw.lower()
    for seq in SEQUENCES:
        for i in range(len(seq) - n + 1):
            chunk = seq[i:i + n]
            if chunk in low or chunk[::-1] in low:
                return True
    return False


_WORDS_RAW = """
apple anchor autumn bamboo banner basket beacon bridge butter cabin candle canyon carpet castle
cherry circle cloud clover cobalt copper coral cotton crystal dancer desert dolphin eagle ember
falcon feather forest fossil galaxy garden ginger glacier granite guitar harbor hazel hollow
island jungle kettle ladder lantern lemon lizard magnet maple meadow meteor mirror mountain
mustard needle nickel ocean olive orchid otter paddle panda pepper pillow planet pocket puzzle
quartz rabbit river rocket saddle sailor silver spiral spruce summit sunset tablet thunder
timber tiger tunnel turtle valley velvet violet walnut whisper willow window wizard yellow
zebra zephyr almond breeze cactus comet cricket dune echo fjord gadget harvest iceberg jigsaw
koala lagoon marble nectar oasis pebble quiver raven saffron thistle umbrella vortex walrus
yonder acorn amber badger blossom bonfire cedar compass drizzle ferry flint harp horizon ivory
juniper lotus lighthouse mosaic nutmeg orbit parrot pine prairie quill ripple sparrow tulip
waffle yarn
"""
# Keep only words that would not themselves trigger the password checker's penalties.
WORDS = tuple(sorted(w for w in set(_WORDS_RAW.split()) if not _common_hits(w) and not _has_sequence(w)))
SYMBOLS = "!@#$%^&*()-_=+[]{}"


def passphrase_bits(words=5):
    """True entropy of a passphrase drawn uniformly from WORDS."""
    return round(words * math.log2(len(WORDS)), 1)


def generate_passphrase(words=5, sep="-", rng=None):
    """Random passphrase, e.g. 'copper-lantern-willow-echo-harbor'."""
    rng = rng or secrets.SystemRandom()
    return sep.join(rng.choice(WORDS) for _ in range(max(3, words)))


def _is_clean(pw):
    return (all(re.search(p, pw) for p in (r"[a-z]", r"[A-Z]", r"\d", r"[^A-Za-z0-9]"))
            and not _common_hits(pw) and not _has_sequence(pw)
            and not re.search(r"(.)\1{2,}", pw) and not re.search(r"(19|20)\d\d", pw))


def generate_password(length=20, rng=None):
    """Random password with all four character classes and none of the checker's penalties."""
    rng = rng or secrets.SystemRandom()
    length = max(16, length)  # 16+ always scores 'Strong' with the checker
    alphabet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789" + SYMBOLS
    while True:
        pw = "".join(rng.choice(alphabet) for _ in range(length))
        if _is_clean(pw):
            return pw


def evaluate_password(pw):
    """Score a password 0-100 with feedback. The password is never stored."""
    feedback = []
    if not pw:
        return {"score": 0, "label": "Empty", "bits": 0.0, "feedback": ["Nothing entered."]}

    classes = {
        "lowercase": bool(re.search(r"[a-z]", pw)),
        "uppercase": bool(re.search(r"[A-Z]", pw)),
        "digits": bool(re.search(r"\d", pw)),
        "symbols": bool(re.search(r"[^A-Za-z0-9]", pw)),
    }
    pool = (26 if classes["lowercase"] else 0) + (26 if classes["uppercase"] else 0) \
        + (10 if classes["digits"] else 0) + (32 if classes["symbols"] else 0)
    bits = round(len(pw) * math.log2(pool), 1) if pool else 0.0

    score = min(len(pw), 16) * 3 + sum(classes.values()) * 8
    if len(pw) < 12:
        feedback.append("Use at least 12 characters (16+ is better).")
    for name, present in classes.items():
        if not present:
            feedback.append(f"Add {name}.")

    words = [w for w in re.split(r"[\s\-_.]+", pw) if len(w) >= 3]
    if len(pw) >= 16 and len(words) >= 3:
        score += 20
        feedback.append("Nice - long passphrases are excellent.")

    if len(pw) >= 20:
        score += 10
    hits = _common_hits(pw)
    if hits:
        if len(hits[0]) / len(pw) >= 0.5:  # the password is basically that common word
            score = min(score - 40, 15)
            bits = min(bits, 20.0)
            feedback.append("This is essentially a very common password (even with substitutions).")
        else:  # a common word inside otherwise longer text is a smaller penalty
            score -= 15
            feedback.append(f"Contains the common word '{hits[0]}' - avoid predictable words.")
    if _has_sequence(pw):
        score -= 15
        feedback.append("Avoid keyboard/number sequences like 1234 or qwer.")
    if re.search(r"(.)\1{2,}", pw):
        score -= 10
        feedback.append("Avoid repeated characters (aaa, 111).")
    if re.search(r"(19|20)\d\d", pw):
        score -= 8
        feedback.append("Avoid years / birth dates.")
    if len(set(pw)) < max(4, len(pw) // 3):
        score -= 10
        feedback.append("Too few unique characters.")

    score = max(0, min(100, score))
    label = ("Very Weak" if score < 30 else "Weak" if score < 50 else "Fair" if score < 70
             else "Strong" if score < 85 else "Very Strong")
    if not feedback:
        feedback.append("Looks great. Use a unique password for every account and turn on MFA.")
    return {"score": score, "label": label, "bits": bits, "feedback": feedback}


# ======================================================================
# SEARCH
# ======================================================================
def filter_records(records, keyword="", category=None, level=None, min_pct=None, max_pct=None):
    kw = keyword.strip().lower()
    out = []
    for r in records:
        if category and r.category != category:
            continue
        if level and r.level != level:
            continue
        if min_pct is not None and r.percent < min_pct:
            continue
        if max_pct is not None and r.percent > max_pct:
            continue
        if kw:
            hay = " ".join([r.player, CATEGORY_LABELS.get(r.category, ""), r.level, r.timestamp]).lower()
            if kw not in hay:
                continue
        out.append(r)
    return sorted(out, key=lambda r: r.timestamp, reverse=True)


# ======================================================================
# STORAGE
# ======================================================================
DEFAULT_PATH = Path(__file__).parent / "data" / "records.json"


class Store:
    def __init__(self, path=DEFAULT_PATH):
        self.path = Path(path)
        self.records = []
        self.notices = []  # human-readable messages from loading
        self.load()

    # ---- loading -------------------------------------------------------
    def load(self):
        self.records, self.notices = [], []
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            self._write([])
            self.notices.append("No data file found - created a fresh one.")
            return
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8") or "null")
            if not isinstance(raw, list):
                raise ValueError("top-level JSON value must be a list")
        except (json.JSONDecodeError, ValueError, UnicodeDecodeError, OSError) as exc:
            stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
            backup = self.path.with_name(f"{self.path.stem}.corrupt-{stamp}.json")
            try:
                os.replace(self.path, backup)
                self.notices.append(f"Data file was unreadable ({exc}). Moved to {backup.name}; started fresh.")
            except OSError:
                self.notices.append(f"Data file was unreadable ({exc}); started fresh.")
            self._write([])
            return

        skipped, seen = 0, set()
        for row in raw:
            try:
                rec = QuizRecord.from_dict(row)
            except (ValueError, TypeError, AttributeError):
                skipped += 1
                continue
            self.records.append(rec)
        # repair missing / duplicate ids
        for rec in self.records:
            if rec.id <= 0 or rec.id in seen:
                rec.id = self._next_id(seen)
            seen.add(rec.id)
        if skipped:
            self.notices.append(f"Skipped {skipped} invalid record(s) while loading.")

    # ---- writing -------------------------------------------------------
    def _write(self, records):
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps([r.to_dict() for r in records], indent=2), encoding="utf-8")
        os.replace(tmp, self.path)

    def save(self):
        self._write(self.records)

    def _next_id(self, extra=()):
        ids = [r.id for r in self.records] + list(extra)
        return (max(ids) if ids else 0) + 1

    def add(self, record):
        record.id = self._next_id()
        self.records.append(record)
        self.save()
        return record

    def add_many(self, records):
        for r in records:
            r.id = self._next_id()
            self.records.append(r)
        self.save()
        return len(records)

    def delete(self, rec_id):
        """Remove one record by id. -> True if it existed."""
        keep = [r for r in self.records if r.id != rec_id]
        if len(keep) == len(self.records):
            return False
        self.records = keep
        self.save()
        return True

    def clear(self):
        n = len(self.records)
        self.records = []
        self.save()
        return n

    @staticmethod
    def fingerprint(r):
        return (r.player.lower(), r.category, r.correct, r.total, r.timestamp)

    def split_duplicates(self, records):
        """-> (new_records, duplicates). Duplicates match an existing record or an earlier one in the batch."""
        seen = {self.fingerprint(r) for r in self.records}
        fresh, dupes = [], []
        for r in records:
            fp = self.fingerprint(r)
            (dupes if fp in seen else fresh).append(r)
            seen.add(fp)
        return fresh, dupes


# ======================================================================
# QUIZ SESSION
# ======================================================================
def _ask(q, label, rng):
    """Show one question and read an answer. -> (is_correct, chosen_text, correct_text)."""
    options, correct_idx = shuffled(q, rng)
    print("\n" + bold(label) + cyan(f"  [{CATEGORIES[q['category']]}]") + dim(f"  ({q['difficulty']})"))
    print("  " + q["q"])
    for n, opt in enumerate(options, 1):
        print(f"    {n}) {opt}")
    choice = ask_int("  Your answer (1-4): ", 1, 4) - 1
    return choice == correct_idx, options[choice], options[correct_idx]


def run_quiz(player, category, rng=random, difficulty=None):
    """Ask the questions, return (record, wrong_answers).

    Each wrong answer is the question dict plus "your_answer" and "correct_answer".
    """
    questions = select_questions(category, rng, difficulty=difficulty)
    per_cat = {k: [0, 0] for k in CATEGORIES}
    wrong = []
    start = time.monotonic()

    for i, q in enumerate(questions, 1):
        ok, chosen, answer = _ask(q, f"Q{i}/{len(questions)}", rng)
        per_cat[q["category"]][1] += 1
        if ok:
            per_cat[q["category"]][0] += 1
            print(green("  OK Correct!"))
        else:
            print(red(f"  X Not quite. Correct answer: {answer}"))
            print(yellow("  Why: ") + q["why"])
            wrong.append({**q, "your_answer": chosen, "correct_answer": answer})

    duration = time.monotonic() - start
    correct = sum(c for c, _ in per_cat.values())
    total = sum(t for _, t in per_cat.values())
    raw = {"player": player, "category": category, "correct": correct, "total": total,
           "duration_sec": round(duration, 1)}
    if category == FULL:
        for key, (c, t) in per_cat.items():
            raw[f"{key}_correct"], raw[f"{key}_total"] = c, t
    return QuizRecord.from_dict(raw), wrong


def practice(questions, rng=random):
    """Re-ask missed questions without recording a score. -> (correct, total)."""
    right = 0
    for i, q in enumerate(questions, 1):
        ok, _, answer = _ask(q, f"Practice {i}/{len(questions)}", rng)
        if ok:
            right += 1
            print(green("  OK Correct!"))
        else:
            print(red(f"  X Correct answer: {answer}"))
            print(yellow("  Why: ") + q["why"])
    return right, len(questions)


# ======================================================================
# REPORTS
# ======================================================================
CRITICAL_PCT = 40
WEAK_CATEGORY_PCT = 60
MIN_SEC_PER_QUESTION = 1.5
MAX_DURATION_SEC = 1800
RETAKE_DAYS = 30
PASS_PCT = 70


def _trend(records):
    ordered = sorted(records, key=lambda r: r.timestamp)
    if len(ordered) < 6:
        return "Not enough data (need 6+ attempts)", 0.0
    recent = ordered[-5:]
    prior = ordered[max(0, len(ordered) - 10):-5]
    diff = statistics.mean(r.percent for r in recent) - statistics.mean(r.percent for r in prior)
    word = "Improving" if diff >= 3 else "Declining" if diff <= -3 else "Stable"
    return f"{word} ({diff:+.1f} pts: last 5 vs previous {len(prior)})", diff


def summarize(records):
    if not records:
        return None
    pcts = [r.percent for r in records]
    cat_tot = defaultdict(lambda: [0, 0])
    for r in records:
        for key, (c, t) in r.breakdown().items():
            cat_tot[key][0] += c
            cat_tot[key][1] += t
    per_player = defaultdict(list)
    for r in records:
        per_player[r.player].append(r.percent)
    leaderboard = sorted(((p, statistics.mean(v), len(v)) for p, v in per_player.items() if len(v) >= 2),
                         key=lambda x: (-x[1], x[0]))[:5]
    timed = [(r.duration_sec, r.total) for r in records if r.duration_sec > 0]
    trend_text, trend_diff = _trend(records)
    return {
        "attempts": len(records),
        "players": len(per_player),
        "avg": statistics.mean(pcts),
        "median": statistics.median(pcts),
        "pass_rate": sum(p >= PASS_PCT for p in pcts) / len(pcts) * 100,
        "best": max(records, key=lambda r: r.percent),
        "worst": min(records, key=lambda r: r.percent),
        "categories": {k: (v[0] / v[1] * 100, v[0], v[1]) for k, v in cat_tot.items() if v[1]},
        "levels": Counter(r.level for r in records),
        "leaderboard": leaderboard,
        "sec_per_q": (sum(d for d, _ in timed) / sum(t for _, t in timed)) if timed else None,
        "trend": trend_text,
        "trend_diff": trend_diff,
    }


def build_sections(s, ascii_only=True):
    """-> [(title, [lines])] used by both the console and file exporters."""
    sec = []
    ov = [f"Attempts: {s['attempts']} by {s['players']} player(s)",
          f"Average score: {s['avg']:.1f}%  |  Median: {s['median']:.1f}%",
          f"Pass rate (>= {PASS_PCT}%): {s['pass_rate']:.0f}%"]
    if s["sec_per_q"]:
        ov.append(f"Average time per question: {s['sec_per_q']:.1f}s")
    sec.append(("Overview", ov))
    b, w = s["best"], s["worst"]
    sec.append(("Highlights", [
        f"Best attempt:  #{b.id} {b.player} - {b.percent:.0f}% ({CATEGORY_LABELS[b.category]})",
        f"Lowest attempt: #{w.id} {w.player} - {w.percent:.0f}% ({CATEGORY_LABELS[w.category]})"]))
    cat_lines = []
    for key in CATEGORIES:
        if key in s["categories"]:
            pct, c, t = s["categories"][key]
            cat_lines.append(f"{CATEGORIES[key]:<20} {bar(pct, 20, ascii_only)} {pct:5.1f}% ({c}/{t})")
    sec.append(("Average by category", cat_lines or ["No data"]))
    lv = [f"{name:<15} {s['levels'].get(name, 0):>3}" for _, name in LEVELS]
    sec.append(("Level distribution", lv))
    lb = [f"{i}. {p} - {a:.1f}% over {n} attempts" for i, (p, a, n) in enumerate(s["leaderboard"], 1)]
    sec.append(("Leaderboard (2+ attempts)", lb or ["Not enough repeat players"]))
    sec.append(("Trend", [s["trend"]]))
    return sec


def get_warnings(records, now=None):
    """Threshold flags -> [(severity, message)]."""
    now = now or datetime.now()
    out = []
    if not records:
        return out

    def listing(rs):
        txt = ", ".join(f"#{r.id} {r.player} ({r.percent:.0f}%)" for r in rs[:5])
        return txt + (f" ... +{len(rs) - 5} more" if len(rs) > 5 else "")

    low = [r for r in records if r.percent < CRITICAL_PCT]
    if low:
        out.append(("CRITICAL", f"{len(low)} attempt(s) scored below {CRITICAL_PCT}%: {listing(low)}"))
    fast = [r for r in records if r.duration_sec > 0 and r.duration_sec / r.total < MIN_SEC_PER_QUESTION]
    if fast:
        out.append(("WARNING", f"{len(fast)} anomalous attempt(s) under {MIN_SEC_PER_QUESTION}s/question "
                               f"(guessing or scripted?): {listing(fast)}"))
    slow = [r for r in records if r.duration_sec > MAX_DURATION_SEC]
    if slow:
        out.append(("INFO", f"{len(slow)} attempt(s) took over {MAX_DURATION_SEC // 60} minutes: {listing(slow)}"))
    s = summarize(records)
    for key, (pct, _, _) in s["categories"].items():
        if pct < WEAK_CATEGORY_PCT:
            out.append(("WARNING", f"Weak area: {CATEGORIES[key]} averages {pct:.1f}% (limit {WEAK_CATEGORY_PCT}%)"))
    if s["trend_diff"] <= -5:
        out.append(("WARNING", f"Scores are declining: {s['trend']}"))
    last_seen = {}
    for r in records:
        t = datetime.fromisoformat(r.timestamp)
        if r.player not in last_seen or t > last_seen[r.player]:
            last_seen[r.player] = t
    overdue = sorted(p for p, t in last_seen.items() if now - t > timedelta(days=RETAKE_DAYS))
    if overdue:
        out.append(("INFO", f"Refresher due (no quiz in {RETAKE_DAYS}+ days): " + ", ".join(overdue)))
    order = {"CRITICAL": 0, "WARNING": 1, "INFO": 2}
    return sorted(out, key=lambda x: order[x[0]])


# ------------------------------------------------------------------ progress & badges
def pass_streak(records):
    """Longest run of consecutive passing attempts (oldest to newest)."""
    best = cur = 0
    for r in sorted(records, key=lambda r: r.timestamp):
        cur = cur + 1 if r.percent >= PASS_PCT else 0
        best = max(best, cur)
    return best


def category_averages(records):
    """{category: (percent, correct, total)} over whatever breakdown is known."""
    tot = defaultdict(lambda: [0, 0])
    for r in records:
        for key, (c, t) in r.breakdown().items():
            tot[key][0] += c
            tot[key][1] += t
    return {k: (v[0] / v[1] * 100, v[0], v[1]) for k, v in tot.items() if v[1]}


def _all_rounder(rs):
    cats = category_averages(rs)
    return len(cats) == len(CATEGORIES) and all(pct >= PASS_PCT for pct, _, _ in cats.values())


def _comeback(rs):
    ordered = sorted(rs, key=lambda r: r.timestamp)
    return any(b.percent - a.percent >= 20 for a, b in zip(ordered, ordered[1:]))


BADGES = [
    ("First Steps", "Complete your first quiz", lambda rs: len(rs) >= 1),
    ("Dedicated", "Complete 10 quizzes", lambda rs: len(rs) >= 10),
    ("Perfectionist", "Score 100% on any quiz", lambda rs: any(r.percent == 100 for r in rs)),
    ("Full Marks", "Score 100% on a Full Quiz", lambda rs: any(r.percent == 100 and r.category == FULL for r in rs)),
    ("Hat-trick", f"Pass (>= {PASS_PCT}%) three quizzes in a row", lambda rs: pass_streak(rs) >= 3),
    ("All-rounder", f"Average {PASS_PCT}%+ in all three categories", _all_rounder),
    ("Comeback Kid", "Beat your previous score by 20+ points", _comeback),
]


def player_report(records, name):
    """Stats and badges for one player (case-insensitive). None if they have no attempts."""
    rs = sorted((r for r in records if r.player.lower() == name.strip().lower()), key=lambda r: r.timestamp)
    if not rs:
        return None
    cats = category_averages(rs)
    weakest = min(cats, key=lambda k: cats[k][0]) if cats else None
    earned = [(n, d) for n, d, test in BADGES if test(rs)]
    locked = [(n, d) for n, d, test in BADGES if not test(rs)]
    return {"name": rs[0].player, "attempts": len(rs), "avg": statistics.mean(r.percent for r in rs),
            "best": max(rs, key=lambda r: r.percent), "latest": rs[-1], "categories": cats,
            "weakest": weakest, "streak": pass_streak(rs), "earned": earned, "locked": locked,
            "trend": _trend(rs)[0]}


# ------------------------------------------------------------------ exports
def to_markdown(records):
    s = summarize(records)
    lines = ["# Cyber Safety Quiz - Summary Report", "",
             f"_Generated {datetime.now():%Y-%m-%d %H:%M}_", ""]
    if not s:
        return "\n".join(lines + ["No records."])
    for title, body in build_sections(s):
        lines += [f"## {title}", ""] + [f"- {ln}" for ln in body] + [""]
    lines += ["## Warnings", ""]
    warns = get_warnings(records)
    lines += [f"- **{lvl}**: {msg}" for lvl, msg in warns] or ["- None"]
    lines += ["", "## Recent attempts", "", "| ID | Date | Player | Category | Score | % | Level |",
              "|---|---|---|---|---|---|---|"]
    for r in sorted(records, key=lambda r: r.timestamp, reverse=True)[:15]:
        lines.append(f"| {r.id} | {r.timestamp[:16].replace('T', ' ')} | {r.player} | "
                     f"{CATEGORY_LABELS[r.category]} | {r.correct}/{r.total} | {r.percent:.0f}% | {r.level} |")
    return "\n".join(lines) + "\n"


def to_audit_text(records):
    lines = ["CYBER SAFETY QUIZ - AUDIT LOG", f"Generated: {datetime.now():%Y-%m-%d %H:%M:%S}", "=" * 60, ""]
    s = summarize(records)
    if s:
        for title, body in build_sections(s):
            lines += [title.upper(), "-" * len(title)] + [f"  {ln}" for ln in body] + [""]
        lines += ["WARNINGS", "--------"]
        lines += [f"  [{lvl}] {msg}" for lvl, msg in get_warnings(records)] or ["  None"]
        lines += ["", "ALL RECORDS", "-----------"]
        lines += ["  " + ln for ln in table_lines(sorted(records, key=lambda r: r.id))]
    else:
        lines.append("No records.")
    return "\n".join(lines) + "\n"


def write_csv(records, path):
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=CSV_FIELDS)
        w.writeheader()
        for r in sorted(records, key=lambda r: r.id):
            w.writerow(r.to_dict())


def write_chart(records, path):
    """Optional PNG chart (needs matplotlib). Returns path or None."""
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        return None
    s = summarize(records)
    ordered = sorted(records, key=lambda r: r.timestamp)
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(11, 4))
    keys = [k for k in CATEGORIES if k in s["categories"]]
    a1.bar([CATEGORIES[k] for k in keys], [s["categories"][k][0] for k in keys], color="#3b82f6")
    a1.axhline(PASS_PCT, ls="--", color="gray")
    a1.set_ylim(0, 100)
    a1.set_title("Average score by category (%)")
    a1.tick_params(axis="x", labelsize=8)
    a2.plot(range(1, len(ordered) + 1), [r.percent for r in ordered], marker="o", ms=3)
    a2.axhline(PASS_PCT, ls="--", color="gray")
    a2.set_ylim(0, 105)
    a2.set_title("Score trend (attempt order)")
    fig.tight_layout()
    fig.savefig(path, dpi=120)
    plt.close(fig)
    return path


def export_all(records, outdir):
    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    paths = []
    p = outdir / f"summary_{stamp}.md"
    p.write_text(to_markdown(records), encoding="utf-8")
    paths.append(p)
    p = outdir / f"audit_{stamp}.txt"
    p.write_text(to_audit_text(records), encoding="utf-8")
    paths.append(p)
    p = outdir / f"records_{stamp}.csv"
    write_csv(records, p)
    paths.append(p)
    if records:
        chart = write_chart(records, outdir / f"chart_{stamp}.png")
        if chart:
            paths.append(chart)
    return paths


# ======================================================================
# IMPORTER
# ======================================================================
REQUIRED = ["player", "category", "correct", "total"]


def import_csv(path, log_path):
    """-> (valid_records, errors[(line_no, message)]). Raises OSError / ValueError for file-level problems."""
    records, errors = [], []
    with open(path, newline="", encoding="utf-8-sig") as fh:
        reader = csv.DictReader(fh)
        if not reader.fieldnames:
            raise ValueError("file is empty")
        headers = [h.strip().lower() for h in reader.fieldnames if h]
        missing = [c for c in REQUIRED if c not in headers]
        if missing:
            raise ValueError(f"missing required column(s): {', '.join(missing)}")
        for row in reader:
            line = reader.line_num
            clean = {(k or "").strip().lower(): (v or "").strip() for k, v in row.items() if k}
            if not any(clean.values()):
                continue
            clean["id"] = ""  # ids are always assigned by the store
            try:
                records.append(QuizRecord.from_dict(clean))
            except (ValueError, TypeError) as exc:
                errors.append((line, str(exc)))
    log = Path(log_path)
    log.parent.mkdir(parents=True, exist_ok=True)
    with open(log, "w", encoding="utf-8") as fh:
        fh.write(f"Import of {path} at {datetime.now():%Y-%m-%d %H:%M:%S}\n")
        fh.write(f"Imported: {len(records)}   Rejected: {len(errors)}\n\n")
        for line, msg in errors:
            fh.write(f"line {line}: {msg}\n")
    return records, errors


# ======================================================================
# SEED DATA
# ======================================================================
PLAYERS = {"Aarav Sharma": 0.85, "Priya Reddy": 0.9, "Rohan Mehta": 0.65, "Sneha Iyer": 0.75,
           "Kabir Singh": 0.5, "Ananya Rao": 0.8, "Vikram Nair": 0.4, "Isha Patel": 0.7}
CATS = ["full", "full", "password", "phishing", "online_safety"]
SIZES = {"full": 12, "password": 6, "phishing": 6, "online_safety": 6}


def generate(seed=42):
    rng = random.Random(seed)
    now = datetime.now()
    rows = []
    for _ in range(36):
        player = rng.choice(list(PLAYERS))
        cat = rng.choice(CATS)
        total = SIZES[cat]
        correct = sum(rng.random() < PLAYERS[player] for _ in range(total))
        ts = now - timedelta(days=rng.uniform(0, 28), minutes=rng.randint(0, 600))
        rows.append(dict(player=player, category=cat, correct=correct, total=total,
                         timestamp=ts.isoformat(timespec="seconds"),
                         duration_sec=round(total * rng.uniform(5, 16), 1)))
    # a player who has not practised for a while (triggers "refresher due")
    for days, c in ((52, 7), (45, 8)):
        ts = now - timedelta(days=days)
        rows.append(dict(player="Old Timer", category="full", correct=c, total=12,
                         timestamp=ts.isoformat(timespec="seconds"), duration_sec=130.0))
    # edge cases & boundary values
    edge = [("Edge Perfect", "full", 12, 12, 150.0), ("Edge Zero", "full", 0, 12, 95.0),
            ("Speed Racer", "full", 12, 12, 9.0), ("Edge Perfect", "password", 6, 6, 40.0),
            ("Edge Zero", "phishing", 0, 6, 33.0), ("Boundary Ninety", "online_safety", 9, 10, 70.0),
            ("Boundary Seventy", "phishing", 7, 10, 80.0), ("Boundary Fifty", "password", 5, 10, 75.0)]
    for p, cat, c, t, d in edge:
        ts = now - timedelta(days=rng.uniform(0, 20))
        rows.append(dict(player=p, category=cat, correct=c, total=t,
                         timestamp=ts.isoformat(timespec="seconds"), duration_sec=d))
    rows.sort(key=lambda r: r["timestamp"])
    return [QuizRecord.from_dict(r) for r in rows]


def write_sample_files(outdir):
    outdir = Path(outdir)
    recs = generate()
    for i, r in enumerate(recs, 1):
        r.id = i
    (outdir / "sample_records.json").write_text(json.dumps([r.to_dict() for r in recs], indent=2))
    with open(outdir / "sample_records.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=CSV_FIELDS)
        w.writeheader()
        w.writerows(r.to_dict() for r in recs)
    return len(recs)


# ======================================================================
# MAIN
# ======================================================================
BASE = Path(__file__).parent
EXPORT_DIR = BASE / "exports"
ERROR_LOG = BASE / "data" / "import_errors.log"
DEFAULT_IMPORT = BASE / "data" / "legacy_import_sample.csv"


def _rel(path):
    """Path relative to the project folder when possible (for tidy messages)."""
    try:
        return Path(path).relative_to(BASE)
    except ValueError:
        return Path(path)

MENU = """
  1) Take a quiz
  2) Password tools (check / generate)
  3) View all records
  4) Search & filter records
  5) Summary dashboard
  6) Warnings & alerts
  7) Export reports (Markdown / TXT / CSV / chart)
  8) Bulk import from CSV
  9) Load demo data
  10) My progress & badges
  11) Manage data (delete)
  12) Cyber Safety Learning Center
  0) Exit"""

CATEGORY_CHOICES = [("password", "Password Safety (6 questions)"),
                    ("phishing", "Phishing Awareness (6 questions)"),
                    ("online_safety", "Online Safety (6 questions)"),
                    (FULL, "Full Quiz (12 mixed questions)")]


TIPS = {
    "password": ["Use a password manager so every account gets its own unique password.",
                 "Prefer long passphrases (5+ random words) over short, 'complex' passwords.",
                 "Turn on MFA everywhere - ideally an authenticator app, security key or passkey."],
    "phishing": ["Slow down: urgency and fear are the attacker's main tools.",
                 "Don't trust links in messages - type the address yourself or use the official app.",
                 "Verify unexpected requests through a second, trusted channel (call back on a known number)."],
    "online_safety": ["Keep devices and apps updated, and install apps only from official stores.",
                      "Treat public Wi-Fi as untrusted: use mobile data or a VPN for sensitive tasks.",
                      "Share less personal information publicly, and report or block suspicious accounts."],
}


# Short, practical lessons shown in the Learning Center.
LESSONS = {
    "password": [
        ("Use unique passwords", "Give every important account a different password. If one site is breached, attackers cannot reuse that password on your other accounts.", "Use a password manager to create and store unique passwords."),
        ("Choose long passphrases", "Long, unpredictable passphrases are easier to remember and harder to guess than short passwords with predictable substitutions.", "Use several randomly chosen words; avoid names, birthdays and quotes."),
        ("Enable multi-factor authentication", "MFA adds another verification step, so a password alone is not enough to access an account.", "Enable MFA or a passkey on email, banking and social accounts."),
    ],
    "phishing": [
        ("Spot suspicious messages", "Unexpected urgency, threats, prizes and requests for sensitive information are common warning signs. Check the sender and message context.", "Pause and verify surprising requests before acting."),
        ("Check links safely", "A link's displayed text can differ from its destination. Do not open unexpected links or attachments just to investigate them.", "Visit the organisation through its official app or by typing its known address."),
        ("Report and verify", "A message can appear to come from someone you know. Their account may have been compromised.", "Confirm unusual requests using a separate trusted channel and report suspicious messages."),
    ],
    "online_safety": [
        ("Protect personal information", "Public posts can be copied and shared beyond the audience you intended. Avoid posting private details such as addresses, live location or identity documents.", "Review privacy settings and share only what is necessary."),
        ("Keep devices updated", "Updates often fix security weaknesses. Delaying updates can leave known issues unpatched.", "Turn on automatic updates for your operating system, browser and apps."),
        ("Use trusted downloads", "Unofficial downloads may contain unwanted or harmful software. App permissions can also expose more information than an app needs.", "Use official app stores and review permissions before granting access."),
    ],
}


class App:
    def __init__(self, store=None):
        self.store = store if store is not None else Store()
        self.player = None
        self.export_dir = EXPORT_DIR

    # ------------------------------------------------------------ actions
    def learning_center(self):
        header("Cyber Safety Learning Center")
        print("  Choose a topic:")
        topics = [("password", "Password safety"), ("phishing", "Phishing awareness"),
                  ("online_safety", "Online safety")]
        for i, (_, label) in enumerate(topics, 1):
            print(f"  {i}) {label}")
        print("  0) Back")
        choice = ask_int("  Select a topic (0-3): ", 0, 3)
        if choice == 0:
            return
        key, label = topics[choice - 1]
        header(label)
        for number, (title, explanation, action) in enumerate(LESSONS[key], 1):
            print(f"  {number}. {bold(title)}")
            print(f"     {explanation}")
            print(f"     Try this: {green(action)}")
            print()

    def take_quiz(self):
        header("Take a quiz")
        self.player = ask_name(
            f"Your name{f' [Enter = {self.player}]' if self.player else ''}: ", self.player)
        for i, (_, label) in enumerate(CATEGORY_CHOICES, 1):
            print(f"  {i}) {label}")
        category = CATEGORY_CHOICES[ask_int("Choose a quiz (1-4): ", 1, 4) - 1][0]
        print("  Difficulty: 0) Mixed  1) Easy  2) Medium  3) Hard")
        difficulty = [None, *DIFFICULTIES][ask_int("Choose (0-3): ", 0, 3)]

        record, wrong = run_quiz(self.player, category, difficulty=difficulty)
        self.store.add(record)

        header("Results")
        print(f"  {bold(record.player)} - {CATEGORY_LABELS[category]} ({difficulty or 'mixed'})")
        print(f"  Score : {record.correct}/{record.total}  {colour_pct(record.percent)}")
        print(f"  Bar   : {bar(record.percent, 30)}")
        print(f"  Level : {bold(record.level)}   Time: {record.duration_sec:.0f}s")
        for key, (c, t) in record.breakdown().items():
            print(f"    - {CATEGORIES[key]:<20} {c}/{t}")
        if wrong:
            weak = [k for k in CATEGORIES if k in {q["category"] for q in wrong}]
            print(yellow("\n  Brush up on: ") + ", ".join(CATEGORIES[k] for k in weak))
            for k in weak:
                for tip in TIPS[k][:2]:
                    print(f"    - {tip}")
        else:
            print(green("\n  Perfect score - great job!"))
        print(dim(f"  Saved as record #{record.id}."))
        if wrong and ask_yes_no(f"\n  Retry your {len(wrong)} missed question(s) as practice (not scored)? (y/n) [n]: ", False):
            right, total = practice(wrong)
            print(f"\n  Practice result: {right}/{total}")

    def password_checker(self):
        header("Password strength checker")
        print(dim("  Your password is analysed locally and never stored or saved."))
        pw = getpass.getpass("  Enter a password to test (hidden): ")
        res = evaluate_password(pw)
        print(f"\n  Strength: {colour_pct(res['score'], res['label'])}  ({res['score']}/100)")
        print(f"  {bar(res['score'], 30)}   ~{res['bits']} bits (rough estimate)")
        for tip in res["feedback"]:
            print(f"   - {tip}")

    def password_tools(self):
        header("Password tools")
        print("  1) Check a password's strength\n  2) Generate a passphrase\n"
              "  3) Generate a random password\n  0) Back")
        choice = ask_int("Choose (0-3): ", 0, 3)
        if choice == 1:
            self.password_checker()
        elif choice == 2:
            n = ask_int("  Number of words (3-10) [5 is a good start]: ", 3, 10)
            pw = generate_passphrase(n)
            res = evaluate_password(pw)
            print(f"\n  {bold(pw)}")
            print(f"  Strength: {colour_pct(res['score'], res['label'])}   ~{passphrase_bits(n)} bits "
                  f"(from a {len(WORDS)}-word list; 6+ words is better for a master password)")
            print(dim("  Generated locally and never stored. Memorise it or put it in a password manager."))
        elif choice == 3:
            n = ask_int("  Length (16-64) [20 is a good start]: ", 16, 64)
            pw = generate_password(n)
            res = evaluate_password(pw)
            print(f"\n  {bold(pw)}")
            print(f"  Strength: {colour_pct(res['score'], res['label'])}   ~{res['bits']} bits (rough estimate)")
            print(dim("  Generated locally and never stored. Save it straight into a password manager."))

    def progress(self):
        header("My progress & badges")
        name = ask_name(f"Player name{f' [Enter = {self.player}]' if self.player else ''}: ", self.player)
        rep = player_report(self.store.records, name)
        if not rep:
            print(yellow(f"  No attempts found for {name} yet - take a quiz first."))
            return
        best, latest = rep["best"], rep["latest"]
        print(f"  {bold(rep['name'])}: {rep['attempts']} attempt(s), average {colour_pct(rep['avg'])}")
        print(f"  Best   : {best.percent:.0f}% ({CATEGORY_LABELS[best.category]})   "
              f"Latest: {latest.percent:.0f}% ({CATEGORY_LABELS[latest.category]})")
        print(f"  Streak : {rep['streak']} passing quiz(zes) in a row   Trend: {rep['trend']}")
        if rep["categories"]:
            print("\n  " + bold("By category"))
            for key in CATEGORIES:
                if key in rep["categories"]:
                    pct, c, t = rep["categories"][key]
                    print(f"    {CATEGORIES[key]:<20} {bar(pct, 20)} {colour_pct(pct, f'{pct:5.1f}%')} ({c}/{t})")
            if rep["categories"][rep["weakest"]][0] < PASS_PCT:
                print(yellow(f"\n  Focus area: {CATEGORIES[rep['weakest']]}"))
                print(f"    - {TIPS[rep['weakest']][0]}")
        print("\n  " + bold("Badges"))
        for n, d in rep["earned"]:
            print(f"    [x] {green(n):<24} {d}")
        for n, d in rep["locked"]:
            print(dim(f"    [ ] {n:<15} {d}"))

    def manage_data(self):
        header("Manage data")
        print("  1) Delete one record by ID\n  2) Delete ALL records\n  0) Back")
        choice = ask_int("Choose (0-2): ", 0, 2)
        if choice == 0:
            return
        if not self.store.records:
            print(yellow("  There are no records."))
            return
        if choice == 1:
            ids = {r.id for r in self.store.records}
            rid = ask_int(f"  Record ID (1-{max(ids)}): ", 1, max(ids))
            if rid not in ids:
                print(red(f"  No record with ID {rid}."))
            elif ask_yes_no(f"  Delete record #{rid}? (y/n): "):
                self.store.delete(rid)
                print(green(f"  Deleted record #{rid}."))
        else:
            n = len(self.store.records)
            if ask_text(f"  Type DELETE to erase all {n} record(s): ") == "DELETE":
                self.store.clear()
                print(green(f"  Deleted {n} record(s)."))
            else:
                print(dim("  Cancelled - nothing was deleted."))

    def view_all(self):
        paginate(sorted(self.store.records, key=lambda r: r.timestamp, reverse=True), 10, "All records")

    def search(self):
        header("Search & filter")
        kw = ask_text("Keyword (name/category/level/date, blank = any): ")
        print("  Category: 0) any  " + "  ".join(f"{i}) {CATEGORY_LABELS[k]}"
                                                for i, k in enumerate(CATEGORY_CHOICES_KEYS, 1)))
        cat_i = ask_int("  Choose (0-4): ", 0, 4)
        print("  Level: 0) any  " + "  ".join(f"{i}) {n}" for i, (_, n) in enumerate(LEVELS, 1)))
        lvl_i = ask_int("  Choose (0-4): ", 0, 4)
        lo = ask_optional_int("Minimum % (blank = none): ", 0, 100)
        hi = ask_optional_int("Maximum % (blank = none): ", 0, 100)
        if lo is not None and hi is not None and lo > hi:
            lo, hi = hi, lo
            print(yellow("  (min/max were swapped)"))
        found = filter_records(self.store.records, kw,
                               CATEGORY_CHOICES_KEYS[cat_i - 1] if cat_i else None,
                               LEVELS[lvl_i - 1][1] if lvl_i else None, lo, hi)
        paginate(found, 10, f"{len(found)} match(es)")

    def dashboard(self):
        header("Executive summary")
        s = summarize(self.store.records)
        if not s:
            print(yellow("  No data yet - take a quiz or load demo data."))
            return
        for title, lines in build_sections(s, ascii_only=False):
            print("\n  " + bold(title))
            for ln in lines:
                print("    " + ln)
        warns = get_warnings(self.store.records)
        crit = sum(1 for lvl, _ in warns if lvl == "CRITICAL")
        print("\n  " + (red(f"{len(warns)} alert(s), {crit} critical - see option 6.") if crit
                        else yellow(f"{len(warns)} alert(s) - see option 6.") if warns
                        else green("No alerts.")))

    def warnings(self):
        header("Warnings & alerts")
        warns = get_warnings(self.store.records)
        if not warns:
            print(green("  All clear - nothing exceeds the thresholds."))
        colour = {"CRITICAL": red, "WARNING": yellow, "INFO": cyan}
        for lvl, msg in warns:
            print(f"  {colour[lvl](f'[{lvl}]')} {msg}")

    def export(self):
        header("Export reports")
        if not self.store.records:
            print(yellow("  Nothing to export yet."))
            return
        paths = export_all(self.store.records, self.export_dir)
        for p in paths:
            print(green("  Wrote ") + str(_rel(p)))
        if not any(p.suffix == ".png" for p in paths):
            print(dim("  (Install matplotlib for an extra PNG chart: pip install matplotlib)"))

    def bulk_import(self):
        header("Bulk import from CSV")
        print(dim("  Required columns: player, category, correct, total  |  optional: timestamp, duration_sec"))
        raw = ask_text(f"CSV path [Enter = {_rel(DEFAULT_IMPORT)}]: ").strip("\"'")
        path = Path(raw) if raw else DEFAULT_IMPORT
        try:
            records, errors = import_csv(path, ERROR_LOG)
        except FileNotFoundError:
            print(red(f"  File not found: {path}"))
            return
        except (OSError, ValueError, UnicodeDecodeError) as exc:
            print(red(f"  Could not import: {exc}"))
            return
        print(f"  Valid rows: {green(str(len(records)))}   Rejected rows: {red(str(len(errors)))}")
        for line, msg in errors[:10]:
            print(red(f"    line {line}: ") + msg)
        if len(errors) > 10:
            print(dim(f"    ... {len(errors) - 10} more in {_rel(ERROR_LOG)}"))
        elif errors:
            print(dim(f"  Full error log: {_rel(ERROR_LOG)}"))
        if not records:
            return
        fresh, dupes = self.store.split_duplicates(records)
        if dupes:
            print(yellow(f"  Skipping {len(dupes)} duplicate record(s) already in your data."))
        if not fresh:
            print(dim("  Nothing new to import."))
        elif ask_yes_no(f"  Save the {len(fresh)} new record(s)? (y/n): "):
            self.store.add_many(fresh)
            print(green("  Imported."))

    def load_demo(self):
        header("Load demo data")
        if not ask_yes_no("  Add 46 realistic sample records to your data? (y/n): "):
            return
        n = self.store.add_many(generate())
        print(green(f"  Added {n} records."))

    # ------------------------------------------------------------ loop
    def run(self):
        banner()
        for note in self.store.notices:
            print(yellow("  ! " + note))
        print(dim(f"  {len(self.store.records)} record(s) loaded."))
        actions = {1: self.take_quiz, 2: self.password_tools, 3: self.view_all, 4: self.search,
                   5: self.dashboard, 6: self.warnings, 7: self.export, 8: self.bulk_import,
                   9: self.load_demo, 10: self.progress, 11: self.manage_data, 12: self.learning_center}
        while True:
            print(MENU)
            choice = ask_int("\nSelect an option (0-12): ", 0, 12)
            if choice == 0:
                print(cyan("\nStay safe online! Goodbye.\n"))
                return
            try:
                actions[choice]()
            except OSError as exc:
                print(red(f"  File error: {exc}"))


CATEGORY_CHOICES_KEYS = [k for k, _ in CATEGORY_CHOICES]

def build_parser():
    ap = argparse.ArgumentParser(
        prog="cyber_safety_quiz",
        description="Cyber Safety Quiz - learn password, phishing and online-safety habits. "
                    "Run without options for the interactive menu.")
    ap.add_argument("--version", action="store_true", help="show the version and exit")
    ap.add_argument("--data", metavar="FILE", help="use this records.json instead of data/records.json")
    ap.add_argument("--demo", action="store_true", help="load the demo records first (only if there are none)")
    ap.add_argument("--stats", action="store_true", help="print the dashboard and alerts, then exit")
    ap.add_argument("--export", metavar="DIR", nargs="?", const="",
                    help="write the report files (default folder: exports/) and exit")
    ap.add_argument("--sample-files", metavar="DIR", help="write sample_records.json/.csv into DIR and exit")
    return ap


def main(argv=None):
    args = build_parser().parse_args(argv)
    if args.version:
        print(f"Cyber Safety Quiz {__version__}")
        return 0
    if args.sample_files:
        out = Path(args.sample_files)
        out.mkdir(parents=True, exist_ok=True)
        print(f"Wrote {write_sample_files(out)} sample records to {out}")
        return 0

    app = App(Store(Path(args.data)) if args.data else Store())
    if args.demo and not app.store.records:
        print(f"Loaded {app.store.add_many(generate())} demo records.")
    headless = args.stats or args.export is not None
    if headless:
        for note in app.store.notices:
            print(yellow("! " + note))
    if args.stats:
        app.dashboard()
        app.warnings()
    if args.export is not None:
        if args.export:
            app.export_dir = Path(args.export)
        app.export()
    if headless:
        return 0
    try:
        app.run()
    except (KeyboardInterrupt, EOFError):
        print(cyan("\n\nInterrupted. Saved records are kept (an unfinished quiz is not recorded). Goodbye!\n"))
    return 0


if __name__ == "__main__":
    sys.exit(main())
