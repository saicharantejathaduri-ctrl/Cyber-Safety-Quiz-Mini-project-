# Cyber Safety Quiz

A Cyber Safety learning application with both a terminal interface and a graphical desktop interface. It teaches password, phishing and online-safety habits through quizzes, tools and progress tracking.
Python 3.10+, standard library only (matplotlib is optional, for a PNG chart on export). See `requirements.txt`.

## Quick start

### Graphical desktop app (recommended)
    python launch_gui.py

The GUI supports student registration/sign-in, interactive quizzes with explanations, a student dashboard, quiz history, a learning center, and local password-strength/generation tools. Student accounts and attempts are stored in `data/cyber_safety_gui.db` using SQLite. Passwords are stored as salted PBKDF2-HMAC-SHA256 hashes (never plaintext). The GUI uses Tkinter, included with most standard Python installations.

### Terminal app
    python cyber_safety_quiz.py                     # interactive menu
    python cyber_safety_quiz.py --demo --stats      # demo data + dashboard, no menu
    python -m unittest -v                           # run all automated tests

## Command-line options
| Option | What it does |
|---|---|
| `--demo` | Load 46 demo records (only if you have none yet) |
| `--stats` | Print the dashboard and alerts, then exit |
| `--export [DIR]` | Write the Markdown/TXT/CSV (+PNG) reports and exit |
| `--data FILE` | Use a different records file |
| `--sample-files DIR` | Write sample JSON/CSV files for testing imports |
| `--version`, `--help` | Version and usage |

## Graphical app
- Student registration and sign-in with salted password hashing.
- Interactive quizzes with randomized answer order and immediate explanations.
- Dashboard with quiz count, average score, personal best and recent activity.
- Quiz history, three short learning topics, local password checker and secure password generator.
- SQLite persistence for student accounts and attempts.

## Menu
1. **Take a quiz** - Password, Phishing, Online Safety or a 12-question Full Quiz; choose Mixed / Easy / Medium / Hard. Wrong answers are explained immediately, followed by targeted tips and an optional **retry of the questions you missed** (practice only, not scored).
2. **Password tools** - strength checker (leetspeak-aware, never stored), **passphrase generator** and **random password generator** (using `secrets`).
3. **View all records** - paginated table.
4. **Search & filter** - by keyword, category, level and score range.
5. **Summary dashboard** - averages, pass rate, category bars, leaderboard, trend.
6. **Warnings & alerts** - low scores, suspiciously fast attempts, weak categories, declining trend, overdue refreshers.
7. **Export reports** - Markdown, TXT audit log, CSV and an optional PNG chart.
8. **Bulk import from CSV** - validates every row, logs rejects with line numbers, skips duplicates.
9. **Load demo data**
10. **My progress & badges** - personal stats, focus area and 7 badges (First Steps, Dedicated, Perfectionist, Full Marks, Hat-trick, All-rounder, Comeback Kid).
11. **Manage data** - delete one record, or erase everything (typed confirmation).
12. **Cyber Safety Learning Center** - short lessons and practical actions for password safety, phishing awareness and online safety.

## Question bank
45 questions (15 per category), each tagged easy / medium / hard with at least 3 per category and level. Single-category quizzes draw 6 random questions; the Full Quiz draws 4 from each category.

## Design notes
- **Single file, no dependencies.** The app is `cyber_safety_quiz.py`; `data/records.json` is created on first run.
- **One validation path.** `QuizRecord.from_dict` is used by the quiz, the JSON loader and the CSV importer. Timestamps with time zones are normalised and future dates are rejected.
- **Safe storage.** Atomic writes, corrupt files are backed up and replaced, and duplicate or missing IDs are repaired on load.
- **Honest numbers.** The password checker is a heuristic, not a cracking-time estimate. Entropy is labelled "rough estimate". For generated passphrases the real entropy comes from the word-list size (150 words, about 7.2 bits per word), so the tool recommends 6+ words for a master password.
- **Accessible output.** Honours `NO_COLOR`, falls back to ASCII bars when the terminal isn't UTF-8.

## Testing
79 automated tests pass: 71 core tests cover validation, scoring, storage, import/export, reports, generators, badges and the CLI; 8 additional tests cover GUI SQLite registration/login/history, edge cases, and question-key compatibility (`q` / `question`). Interactive terminal flows are tested end to end by scripting `input()`. The GUI is syntax-checked and importable without tkinter (Database layer only); full visual layout should be smoke-tested on the target desktop.

## Sample import file
`data/legacy_import_sample.csv` is the default for menu option 8. It has 12 valid rows (one exact duplicate, plus time-zone and alias examples) and 5 deliberately invalid rows.

## Changelog
**2.1.0**
- Fixed: GUI quiz crash (`q['question']` vs core `'q'` key) — questions now expose both keys.
- Improved GUI: readable layout, scrollable content, passphrase generator, difficulty shown in history, safer password display after generate, empty-pool guard, optional tkinter (Database layer works headless).
- Expanded tests: 79 total (was 74); GUI DB edge cases + question-key compatibility.
- Added `requirements.txt` (stdlib + optional matplotlib).

**2.0.0**
- New: difficulty levels, 45 questions, retry-missed practice, study tips, progress screen with badges, passphrase and password generators, record deletion, command-line options, shipped sample CSV.
- Fixed: crash on timezone-aware timestamps; common words inside long passphrases no longer fail the checker; random-password generator enforces 16+ characters to match the checker's scoring.
- Improved: explicit `answer` field on questions, duplicate detection on import, 69 tests (33 before).

**1.x** - original project: quiz, password checker, records, search, dashboard, alerts, exports, import.

**GUI launch:** `python launch_gui.py`
