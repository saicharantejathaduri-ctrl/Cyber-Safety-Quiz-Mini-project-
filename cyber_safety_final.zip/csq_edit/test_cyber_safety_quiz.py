"""Unit tests for cyber_safety_quiz.py  (run:  python -m unittest -v)."""
import contextlib
import csv
import io
import json
import random
import sys
import tempfile
import unittest
from collections import Counter
from datetime import datetime, timedelta
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).parent))
import cyber_safety_quiz as csq  # noqa: E402


def setUpModule():
    csq.USE_COLOR = False  # keep captured output free of ANSI codes


def feed(inputs):
    """Patch input() with scripted answers (EOFError once they run out)."""
    it = iter(inputs)

    def fake(prompt=""):
        try:
            return str(next(it))
        except StopIteration:
            raise EOFError from None
    return mock.patch("builtins.input", fake)


def capture(fn, *a, **kw):
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        result = fn(*a, **kw)
    return result, buf.getvalue()


def correct_answers(category, seed, difficulty=None):
    """Replay the RNG stream run_quiz will use to know each question's right option number."""
    rng = random.Random(seed)
    qs = csq.select_questions(category, rng, difficulty=difficulty)
    return [str(csq.shuffled(q, rng)[1] + 1) for q in qs]


def wrong_number(n):
    return str(int(n) % 4 + 1)


def rec(player="Test User", category="password", correct=5, total=6, **kw):
    d = dict(player=player, category=category, correct=correct, total=total, **kw)
    return csq.QuizRecord.from_dict(d)


class TestBasics(unittest.TestCase):
    def test_level_boundaries(self):
        self.assertEqual(csq.level_for(100), "Cyber Guardian")
        self.assertEqual(csq.level_for(90), "Cyber Guardian")
        self.assertEqual(csq.level_for(89.9), "Safe Surfer")
        self.assertEqual(csq.level_for(70), "Safe Surfer")
        self.assertEqual(csq.level_for(50), "Getting There")
        self.assertEqual(csq.level_for(49.9), "At Risk")
        self.assertEqual(csq.level_for(0), "At Risk")

    def test_clean_name(self):
        self.assertEqual(csq.clean_name("  Priya   Reddy "), "Priya Reddy")
        self.assertEqual(csq.clean_name("O'Brien-Smith Jr."), "O'Brien-Smith Jr.")
        for bad in ("", "A", "1abc", "<script>", None, "x" * 31):
            self.assertIsNone(csq.clean_name(bad), bad)


class TestRecordValidation(unittest.TestCase):
    def test_valid_record(self):
        r = rec(correct=9, total=10)
        self.assertEqual(r.percent, 90.0)
        self.assertEqual(r.level, "Cyber Guardian")

    def test_aliases_and_float_ints(self):
        r = csq.QuizRecord.from_dict({"player": "Test User", "category": "Online Safety",
                                      "correct": "4.0", "total": "6"})
        self.assertEqual(r.category, "online_safety")
        self.assertEqual(r.correct, 4)

    def test_rejects_bad_data(self):
        base = dict(player="Test User", category="password", correct=3, total=6)
        for patch in ({"player": "!!"}, {"category": "maths"}, {"correct": 7}, {"correct": -1},
                      {"total": 0}, {"correct": "x"}, {"timestamp": "yesterday"},
                      {"duration_sec": "-5"}, {"duration_sec": "abc"}):
            with self.assertRaises(ValueError, msg=str(patch)):
                csq.QuizRecord.from_dict({**base, **patch})

    def test_timezone_aware_timestamps_are_normalised(self):
        """Regression: aware timestamps used to crash get_warnings (aware - naive)."""
        stamp = (datetime.now() - timedelta(days=60)).strftime("%Y-%m-%dT%H:%M:%S")
        for suffix in ("+05:30", "Z", "-08:00"):
            r = rec(timestamp=stamp + suffix)
            self.assertIsNone(datetime.fromisoformat(r.timestamp).tzinfo)
            csq.get_warnings([r])  # must not raise
            csq.summarize([r])

    def test_future_timestamp_rejected(self):
        future = (datetime.now() + timedelta(days=30)).isoformat(timespec="seconds")
        with self.assertRaises(ValueError):
            rec(timestamp=future)

    def test_full_quiz_breakdown_must_add_up(self):
        good = dict(player="Test User", category="full", correct=9, total=12,
                    password_correct=3, password_total=4, phishing_correct=3, phishing_total=4,
                    online_safety_correct=3, online_safety_total=4)
        self.assertEqual(len(csq.QuizRecord.from_dict(good).breakdown()), 3)
        with self.assertRaises(ValueError):
            csq.QuizRecord.from_dict({**good, "password_correct": 1})
        with self.assertRaises(ValueError):
            csq.QuizRecord.from_dict({**good, "phishing_total": ""})


class TestQuestionBank(unittest.TestCase):
    def test_structure(self):
        self.assertGreaterEqual(len(csq.QUESTIONS), 30)
        for q in csq.QUESTIONS:
            self.assertIn(q["category"], csq.CATEGORIES)
            self.assertEqual(len(q["options"]), 4, q["q"])
            self.assertEqual(len(set(q["options"])), 4, q["q"])
            self.assertIn(q["answer"], q["options"], q["q"])
            self.assertTrue(q["why"].strip())

    def test_unique_questions_and_pool_sizes(self):
        self.assertEqual(len({q["q"] for q in csq.QUESTIONS}), len(csq.QUESTIONS))
        counts = Counter(q["category"] for q in csq.QUESTIONS)
        for key in csq.CATEGORIES:
            self.assertGreaterEqual(counts[key], 8, key)

    def test_selection_sizes_and_no_repeats(self):
        rng = random.Random(1)
        full = csq.select_questions("full", rng)
        self.assertEqual(len(full), 12)
        self.assertEqual(Counter(q["category"] for q in full), Counter({k: 4 for k in csq.CATEGORIES}))
        for key in csq.CATEGORIES:
            single = csq.select_questions(key, rng)
            self.assertEqual(len(single), 6)
            self.assertEqual(len({q["q"] for q in single}), 6)
            self.assertTrue(all(q["category"] == key for q in single))

    def test_shuffle_tracks_correct_answer(self):
        rng = random.Random(7)
        for q in csq.QUESTIONS:
            for _ in range(5):
                options, idx = csq.shuffled(q, rng)
                self.assertEqual(options[idx], q["answer"])
                self.assertEqual(sorted(options), sorted(q["options"]))


class TestPasswordChecker(unittest.TestCase):
    def score(self, pw):
        return csq.evaluate_password(pw)["score"]

    def test_empty(self):
        self.assertEqual(csq.evaluate_password("")["label"], "Empty")

    def test_common_passwords_are_very_weak(self):
        for pw in ("password", "P@ssw0rd1", "Summer2024!", "qwerty123456", "Letmein1", "admin123"):
            self.assertLessEqual(self.score(pw), 15, pw)

    def test_long_passphrase_with_common_word_not_crushed(self):
        self.assertGreaterEqual(self.score("winter-orchid-lantern-copper"), 60)

    def test_strong_beats_weak(self):
        self.assertGreater(self.score("Xk9#mQ2$vL7!pR4z"), self.score("Welcome1"))
        self.assertGreaterEqual(self.score("correct-horse-battery-staple-92"), 85)

    def test_leetspeak_one_variants(self):
        self.assertLessEqual(self.score("l0g1nl0g1n"), 15)  # 1 -> i  ("login")
        self.assertLessEqual(self.score("sunsh1ne99"), 15)  # 1 -> i  ("sunshine")

    def test_bits_estimate_capped_for_common(self):
        self.assertLessEqual(csq.evaluate_password("P@ssw0rd1")["bits"], 20.0)

    def test_penalties(self):
        self.assertLess(self.score("Kq7#aaaaZm2!"), self.score("Kq7#bnaxZm2!"))  # repeats
        self.assertLess(self.score("Kq7#1234Zm2!"), self.score("Kq7#8203Zm2!"))  # sequence

    def test_score_bounds(self):
        for pw in ("a", "A" * 100, "!" * 50, "Xk9#mQ2$vL7!pR4zXk9#mQ2$vL7!pR4z"):
            self.assertTrue(0 <= self.score(pw) <= 100)


class TestSearchAndReports(unittest.TestCase):
    def setUp(self):
        now = datetime.now()
        self.records = [
            rec("Aarav Sharma", "password", 6, 6, timestamp=(now - timedelta(days=1)).isoformat(), duration_sec=50),
            rec("Vikram Nair", "phishing", 1, 6, timestamp=(now - timedelta(days=2)).isoformat(), duration_sec=40),
            rec("Speed Racer", "full", 12, 12, timestamp=(now - timedelta(days=3)).isoformat(), duration_sec=9),
            rec("Old Timer", "online_safety", 4, 6, timestamp=(now - timedelta(days=60)).isoformat(), duration_sec=40),
        ]

    def test_filter(self):
        f = csq.filter_records
        self.assertEqual(len(f(self.records)), 4)
        self.assertEqual([r.player for r in f(self.records, "vikram")], ["Vikram Nair"])
        self.assertEqual(len(f(self.records, category="full")), 1)
        self.assertEqual(len(f(self.records, level="At Risk")), 1)
        self.assertEqual(len(f(self.records, min_pct=60, max_pct=99)), 1)
        # newest first
        ts = [r.timestamp for r in f(self.records)]
        self.assertEqual(ts, sorted(ts, reverse=True))

    def test_warnings(self):
        msgs = dict((lvl, []) for lvl in ("CRITICAL", "WARNING", "INFO"))
        for lvl, msg in csq.get_warnings(self.records):
            msgs[lvl].append(msg)
        self.assertTrue(any("below" in m and "Vikram" in m for m in msgs["CRITICAL"]))
        self.assertTrue(any("Speed Racer" in m for m in msgs["WARNING"]))
        self.assertTrue(any("Old Timer" in m for m in msgs["INFO"]))
        levels = [lvl for lvl, _ in csq.get_warnings(self.records)]
        self.assertEqual(levels, sorted(levels, key=["CRITICAL", "WARNING", "INFO"].index))

    def test_summarize(self):
        self.assertIsNone(csq.summarize([]))
        s = csq.summarize(self.records)
        self.assertEqual(s["attempts"], 4)
        self.assertEqual(s["best"].percent, 100.0)
        self.assertEqual(s["worst"].player, "Vikram Nair")
        self.assertIn("Not enough data", s["trend"])

    def test_trend_detects_decline(self):
        now = datetime.now()
        recs = [rec(correct=6 if i < 5 else 2, total=6,
                    timestamp=(now - timedelta(days=20 - i)).isoformat()) for i in range(10)]
        self.assertLessEqual(csq.summarize(recs)["trend_diff"], -5)

    def test_exports(self):
        with tempfile.TemporaryDirectory() as d:
            paths = csq.export_all(self.records, d)
            suffixes = {p.suffix for p in paths}
            self.assertTrue({".md", ".txt", ".csv"} <= suffixes)
            self.assertIn("Summary Report", paths[0].read_text(encoding="utf-8"))
        self.assertIn("No records", csq.to_markdown([]))


class TestImport(unittest.TestCase):
    def write_csv(self, d, rows, header=("player", "category", "correct", "total", "timestamp")):
        path = Path(d) / "in.csv"
        with open(path, "w", newline="", encoding="utf-8") as fh:
            w = csv.writer(fh)
            w.writerow(header)
            w.writerows(rows)
        return path

    def test_valid_and_rejected_rows(self):
        with tempfile.TemporaryDirectory() as d:
            path = self.write_csv(d, [
                ["Priya Reddy", "password", 5, 6, "2026-01-05"],
                ["Bad!!", "password", 5, 6, ""],
                ["Rohan Mehta", "maths", 5, 6, ""],
                ["Sneha Iyer", "pw", 9, 6, ""],
                ["Kabir Singh", "phish", 3, 6, "2026-01-06T10:00:00+05:30"],
                ["", "", "", "", ""],
            ])
            log = Path(d) / "logs" / "errors.log"
            records, errors = csq.import_csv(path, log)
            self.assertEqual(len(records), 2)
            self.assertEqual(len(errors), 3)
            self.assertIn("Rejected: 3", log.read_text(encoding="utf-8"))

    def test_missing_columns_and_empty_file(self):
        with tempfile.TemporaryDirectory() as d:
            path = self.write_csv(d, [], header=("player", "category"))
            with self.assertRaises(ValueError):
                csq.import_csv(path, Path(d) / "e.log")
            empty = Path(d) / "empty.csv"
            empty.write_text("")
            with self.assertRaises(ValueError):
                csq.import_csv(empty, Path(d) / "e.log")
            with self.assertRaises(FileNotFoundError):
                csq.import_csv(Path(d) / "nope.csv", Path(d) / "e.log")


class TestStore(unittest.TestCase):
    def test_create_add_reload(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / "data" / "records.json"
            s = csq.Store(path)
            self.assertTrue(any("fresh" in n for n in s.notices))
            s.add(rec())
            s.add(rec("Priya Reddy"))
            s2 = csq.Store(path)
            self.assertEqual([r.id for r in s2.records], [1, 2])
            self.assertEqual(s2.notices, [])

    def test_corrupt_file_is_backed_up(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / "records.json"
            path.write_text("{not json")
            s = csq.Store(path)
            self.assertEqual(s.records, [])
            self.assertTrue(list(Path(d).glob("records.corrupt-*.json")))
            self.assertEqual(json.loads(path.read_text()), [])

    def test_invalid_rows_skipped_and_ids_repaired(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / "records.json"
            good = rec().to_dict()
            good["id"] = 3
            dup = dict(good)
            dup["player"] = "Priya Reddy"
            bad = dict(good, correct=99)
            path.write_text(json.dumps([good, dup, bad, "garbage"]))
            s = csq.Store(path)
            self.assertEqual(len(s.records), 2)
            self.assertEqual(len({r.id for r in s.records}), 2)
            self.assertTrue(any("Skipped 2" in n for n in s.notices))

    def test_duplicate_detection(self):
        with tempfile.TemporaryDirectory() as d:
            s = csq.Store(Path(d) / "records.json")
            ts = "2026-01-05T09:00:00"
            s.add(rec("Priya Reddy", timestamp=ts))
            batch = [rec("priya reddy", timestamp=ts),            # same as stored (case-insensitive)
                     rec("Rohan Mehta", timestamp=ts),            # new
                     rec("Rohan Mehta", timestamp=ts)]            # repeat within the batch
            fresh, dupes = s.split_duplicates(batch)
            self.assertEqual(len(fresh), 1)
            self.assertEqual(len(dupes), 2)
            self.assertEqual(s.add_many(fresh), 1)
            self.assertEqual(len(s.records), 2)


class TestSampleData(unittest.TestCase):
    def test_demo_data_valid_and_triggers_every_alert_type(self):
        recs = csq.generate()
        self.assertGreaterEqual(len(recs), 40)
        levels = {lvl for lvl, _ in csq.get_warnings(recs)}
        self.assertEqual(levels, {"CRITICAL", "WARNING", "INFO"})
        self.assertEqual({r.level for r in recs}, {name for _, name in csq.LEVELS})

    def test_sample_files_roundtrip(self):
        with tempfile.TemporaryDirectory() as d:
            n = csq.write_sample_files(d)
            self.assertEqual(len(json.loads((Path(d) / "sample_records.json").read_text())), n)
            records, errors = csq.import_csv(Path(d) / "sample_records.csv", Path(d) / "e.log")
            self.assertEqual((len(records), len(errors)), (n, 0))


class TestDifficulty(unittest.TestCase):
    def test_every_question_tagged_and_pools_big_enough(self):
        self.assertGreaterEqual(len(csq.QUESTIONS), 45)
        counts = Counter((q["category"], q["difficulty"]) for q in csq.QUESTIONS)
        for key in csq.CATEGORIES:
            for level in csq.DIFFICULTIES:
                self.assertGreaterEqual(counts[(key, level)], 3, (key, level))

    def test_selection_respects_difficulty(self):
        rng = random.Random(2)
        for level in csq.DIFFICULTIES:
            for cat in ("password", "full"):
                qs = csq.select_questions(cat, rng, difficulty=level)
                self.assertTrue(qs)
                self.assertTrue(all(q["difficulty"] == level for q in qs))
        self.assertEqual(len(csq.select_questions("full", rng, difficulty="easy")), 12)


class TestGenerators(unittest.TestCase):
    def test_wordlist_clean_and_unique(self):
        self.assertGreaterEqual(len(csq.WORDS), 128)
        self.assertEqual(len(csq.WORDS), len(set(csq.WORDS)))
        self.assertFalse(any(csq._common_hits(w) or csq._has_sequence(w) for w in csq.WORDS))

    def test_passphrases_are_strong_and_random(self):
        phrases = {csq.generate_passphrase() for _ in range(200)}
        self.assertGreater(len(phrases), 190)
        for ph in list(phrases)[:100]:
            self.assertEqual(len(ph.split("-")), 5)
            self.assertGreaterEqual(csq.evaluate_password(ph)["score"], 70, ph)
        self.assertEqual(len(csq.generate_passphrase(1).split("-")), 3)  # minimum 3 words
        self.assertAlmostEqual(csq.passphrase_bits(5), 5 * __import__("math").log2(len(csq.WORDS)), places=1)

    def test_random_passwords(self):
        for n in (16, 20, 40):
            for _ in range(25):
                pw = csq.generate_password(n)
                self.assertEqual(len(pw), n)
                self.assertTrue(csq._is_clean(pw))
                self.assertGreaterEqual(csq.evaluate_password(pw)["score"], 80)
        self.assertEqual(len(csq.generate_password(3)), 16)  # minimum length
        self.assertNotEqual(csq.generate_password(), csq.generate_password())

    def test_seeded_rng_is_deterministic(self):
        a = csq.generate_passphrase(rng=random.Random(5))
        b = csq.generate_passphrase(rng=random.Random(5))
        self.assertEqual(a, b)


class TestBadges(unittest.TestCase):
    def mk(self, pcts, category="password", start_days_ago=30):
        now = datetime.now()
        out = []
        for i, c in enumerate(pcts):
            ts = (now - timedelta(days=start_days_ago - i)).isoformat(timespec="seconds")
            out.append(rec("Badge Tester", category, c, 10, timestamp=ts))
        return out

    def names(self, records):
        return {n for n, _ in csq.player_report(records, "badge tester")["earned"]}

    def test_no_attempts(self):
        self.assertIsNone(csq.player_report([], "Nobody"))

    def test_first_steps_and_perfect(self):
        got = self.names(self.mk([10]))
        self.assertEqual(got, {"First Steps", "Perfectionist", "Hat-trick"} - {"Hat-trick"})

    def test_hat_trick_and_streak(self):
        recs = self.mk([8, 9, 7, 3, 8])
        self.assertEqual(csq.pass_streak(recs), 3)
        self.assertIn("Hat-trick", self.names(recs))
        self.assertEqual(csq.pass_streak(self.mk([8, 3, 8, 3])), 1)

    def test_dedicated_needs_ten(self):
        self.assertNotIn("Dedicated", self.names(self.mk([5] * 9)))
        self.assertIn("Dedicated", self.names(self.mk([5] * 10)))

    def test_comeback(self):
        self.assertIn("Comeback Kid", self.names(self.mk([3, 6])))
        self.assertNotIn("Comeback Kid", self.names(self.mk([3, 4, 5])))

    def test_full_marks_and_all_rounder(self):
        full = rec("Badge Tester", "full", 12, 12, password_correct=4, password_total=4,
                   phishing_correct=4, phishing_total=4, online_safety_correct=4, online_safety_total=4)
        got = self.names([full])
        self.assertTrue({"Full Marks", "Perfectionist", "All-rounder"} <= got)
        self.assertNotIn("All-rounder", self.names(self.mk([9, 9])))  # only one category

    def test_report_fields(self):
        rep = csq.player_report(self.mk([5, 9]), "BADGE TESTER")  # case-insensitive
        self.assertEqual(rep["attempts"], 2)
        self.assertEqual(rep["best"].percent, 90.0)
        self.assertEqual(rep["weakest"], "password")
        self.assertEqual(len(rep["earned"]) + len(rep["locked"]), len(csq.BADGES))


class TestQuizSession(unittest.TestCase):
    def test_perfect_run(self):
        answers = correct_answers("password", 3)
        with feed(answers):
            (record, wrong), out = capture(csq.run_quiz, "Test User", "password", random.Random(3))
        self.assertEqual((record.correct, record.total, record.percent), (6, 6, 100.0))
        self.assertEqual(wrong, [])
        self.assertIn("Q1/6", out)

    def test_all_wrong_run_collects_details(self):
        answers = [wrong_number(a) for a in correct_answers("phishing", 4)]
        with feed(answers):
            (record, wrong), out = capture(csq.run_quiz, "Test User", "phishing", random.Random(4))
        self.assertEqual(record.correct, 0)
        self.assertEqual(len(wrong), 6)
        for w in wrong:
            self.assertNotEqual(w["your_answer"], w["correct_answer"])
            self.assertEqual(w["correct_answer"], w["answer"])
        self.assertIn("Not quite", out)

    def test_full_quiz_has_breakdown_and_difficulty_label(self):
        answers = correct_answers("full", 6, "hard")
        with feed(answers):
            (record, _), out = capture(csq.run_quiz, "Test User", "full", random.Random(6), "hard")
        self.assertEqual(record.category, "full")
        self.assertEqual(sum(t for _, t in record.breakdown().values()), record.total)
        self.assertIn("(hard)", out)

    def test_invalid_answers_are_reprompted(self):
        answers = correct_answers("online_safety", 8)
        junk = ["", "x", "9", "0", "-1"]
        with feed(junk + answers):
            (record, _), out = capture(csq.run_quiz, "Test User", "online_safety", random.Random(8))
        self.assertEqual(record.percent, 100.0)
        self.assertIn("Enter a number between 1 and 4", out)

    def test_practice_is_not_recorded(self):
        wrong = []
        with feed([wrong_number(a) for a in correct_answers("password", 9)]):
            _, wrong = capture(csq.run_quiz, "Test User", "password", random.Random(9))[0]
        with feed(["1"] * len(wrong)):
            (right, total), out = capture(csq.practice, wrong, random.Random(1))
        self.assertEqual(total, 6)
        self.assertTrue(0 <= right <= 6)
        self.assertIn("Practice 1/6", out)


class TestInteractiveApp(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.dir = Path(self.tmp.name)
        self.app = csq.App(csq.Store(self.dir / "records.json"))
        self.app.export_dir = self.dir / "exports"

    def test_take_quiz_flow_saves_record(self):
        random.seed(11)
        answers = correct_answers("password", 11)
        with feed(["Test User", "1", "0", *answers]):
            _, out = capture(self.app.take_quiz)
        self.assertEqual(len(self.app.store.records), 1)
        self.assertEqual(self.app.store.records[0].percent, 100.0)
        self.assertIn("Perfect score", out)
        self.assertIn("Saved as record #1", out)

    def test_take_quiz_with_mistakes_shows_tips_and_practice(self):
        random.seed(12)
        answers = [wrong_number(a) for a in correct_answers("phishing", 12)]
        with feed(["Test User", "2", "0", *answers, "y", *["1"] * 6]):
            _, out = capture(self.app.take_quiz)
        self.assertEqual(self.app.store.records[0].percent, 0.0)
        self.assertIn("Brush up on: Phishing Awareness", out)
        self.assertIn(csq.TIPS["phishing"][0], out)
        self.assertIn("Practice 6/6", out)
        self.assertIn("Practice result:", out)
        self.assertEqual(len(self.app.store.records), 1)  # practice adds nothing

    def test_name_is_remembered_between_quizzes(self):
        random.seed(13)
        with feed(["Test User", "1", "1", *correct_answers("password", 13, "easy")]):
            capture(self.app.take_quiz)
        self.assertEqual(self.app.player, "Test User")
        random.seed(14)
        with feed(["", "3", "0", *correct_answers("online_safety", 14)]):  # blank name = reuse
            capture(self.app.take_quiz)
        self.assertEqual({r.player for r in self.app.store.records}, {"Test User"})

    def test_menu_loop_demo_dashboard_alerts_exit(self):
        with feed(["9", "y", "5", "6", "0"]):
            _, out = capture(self.app.run)
        for expected in ("Added 46 records", "Executive summary", "Warnings & alerts", "Goodbye"):
            self.assertIn(expected, out)

    def test_menu_rejects_bad_choice(self):
        with feed(["abc", "99", "-1", "0"]):
            _, out = capture(self.app.run)
        self.assertIn("is not a whole number", out)
        self.assertIn("Enter a number between 0 and 12", out)

    def test_empty_states(self):
        for fn, text in ((self.app.dashboard, "No data yet"), (self.app.export, "Nothing to export"),
                         (self.app.view_all, "No records")):
            with feed([]):
                _, out = capture(fn)
            self.assertIn(text, out)

    def test_export_writes_files(self):
        self.app.store.add_many(csq.generate())
        _, out = capture(self.app.export)
        files = {p.suffix for p in (self.dir / "exports").iterdir()}
        self.assertTrue({".md", ".txt", ".csv"} <= files)
        self.assertIn("Wrote", out)

    def test_search_flow(self):
        self.app.store.add_many(csq.generate())
        with feed(["priya", "0", "0", "", ""]):  # keyword, any category, any level, no min/max
            _, out = capture(self.app.search)
        self.assertIn("Priya Reddy", out)
        self.assertNotIn("Vikram Nair", out)

    def test_progress_screen(self):
        with feed(["Nobody Here"]):
            _, out = capture(self.app.progress)
        self.assertIn("No attempts found", out)
        self.app.store.add(rec("Test User", "password", 6, 6))
        with feed(["Test User"]):
            _, out = capture(self.app.progress)
        self.assertIn("[x] First Steps", out)
        self.assertIn("[ ] Dedicated", out)

    def test_manage_data(self):
        self.app.store.add_many([rec("Test User"), rec("Priya Reddy"), rec("Rohan Mehta")])
        with feed(["1", "2", "y"]):
            capture(self.app.manage_data)
        self.assertEqual([r.id for r in self.app.store.records], [1, 3])
        with feed(["1", "2"]):  # id 2 no longer exists
            _, out = capture(self.app.manage_data)
        self.assertIn("No record with ID 2", out)
        with feed(["2", "nope"]):  # wrong confirmation -> nothing deleted
            _, out = capture(self.app.manage_data)
        self.assertEqual(len(self.app.store.records), 2)
        self.assertIn("Cancelled", out)
        with feed(["2", "DELETE"]):
            capture(self.app.manage_data)
        self.assertEqual(self.app.store.records, [])
        self.assertEqual(json.loads((self.dir / "records.json").read_text()), [])

    def test_password_tools(self):
        with feed(["1"]), mock.patch("getpass.getpass", return_value="P@ssw0rd1"):
            _, out = capture(self.app.password_tools)
        self.assertIn("Very Weak", out)
        with feed(["2", "6"]):
            _, out = capture(self.app.password_tools)
        self.assertIn("bits", out)
        self.assertIn("never stored", out)
        with feed(["3", "24"]):
            _, out = capture(self.app.password_tools)
        self.assertIn("Strong", out)

    def test_bulk_import_flow_with_duplicates(self):
        sample = Path(__file__).parent / "data" / "legacy_import_sample.csv"
        with mock.patch.object(csq, "ERROR_LOG", self.dir / "errors.log"):
            with feed([str(sample), "y"]):
                _, out = capture(self.app.bulk_import)
            self.assertIn("Valid rows: 12", out)
            self.assertIn("Rejected rows: 5", out)
            self.assertIn("Skipping 1 duplicate", out)
            self.assertEqual(len(self.app.store.records), 11)
            with feed([str(sample)]):  # second import: everything is a duplicate
                _, out = capture(self.app.bulk_import)
            self.assertIn("Nothing new to import", out)
            self.assertEqual(len(self.app.store.records), 11)
            with feed(["/no/such/file.csv"]):
                _, out = capture(self.app.bulk_import)
            self.assertIn("File not found", out)


class TestCLI(unittest.TestCase):
    def test_version_and_help(self):
        code, out = capture(csq.main, ["--version"])
        self.assertEqual(code, 0)
        self.assertIn(csq.__version__, out)
        with self.assertRaises(SystemExit), contextlib.redirect_stdout(io.StringIO()):
            csq.main(["--help"])

    def test_stats_with_demo_data(self):
        with tempfile.TemporaryDirectory() as d:
            code, out = capture(csq.main, ["--data", str(Path(d) / "r.json"), "--demo", "--stats"])
            self.assertEqual(code, 0)
            self.assertIn("Loaded 46 demo records", out)
            self.assertIn("Executive summary", out)
            self.assertIn("Warnings & alerts", out)
            code, out = capture(csq.main, ["--data", str(Path(d) / "r.json"), "--demo", "--stats"])
            self.assertNotIn("Loaded", out)  # demo only loads into an empty store

    def test_export_headless(self):
        with tempfile.TemporaryDirectory() as d:
            data, outdir = str(Path(d) / "r.json"), Path(d) / "out"
            code, _ = capture(csq.main, ["--data", data, "--demo", "--export", str(outdir)])
            self.assertEqual(code, 0)
            self.assertTrue(list(outdir.glob("summary_*.md")))

    def test_sample_files(self):
        with tempfile.TemporaryDirectory() as d:
            code, out = capture(csq.main, ["--sample-files", d])
            self.assertEqual(code, 0)
            self.assertTrue((Path(d) / "sample_records.csv").exists())

    def test_interactive_mode_handles_eof(self):
        with tempfile.TemporaryDirectory() as d, feed([]):
            code, out = capture(csq.main, ["--data", str(Path(d) / "r.json")])
        self.assertEqual(code, 0)
        self.assertIn("Interrupted", out)


class TestShippedSampleFile(unittest.TestCase):
    def test_legacy_sample_csv(self):
        sample = Path(__file__).parent / "data" / "legacy_import_sample.csv"
        with tempfile.TemporaryDirectory() as d:
            records, errors = csq.import_csv(sample, Path(d) / "e.log")
        self.assertEqual((len(records), len(errors)), (12, 5))
        self.assertEqual({r.category for r in records}, {"password", "phishing", "online_safety", "full"})


if __name__ == "__main__":
    unittest.main(verbosity=2)


class TestLearningCenter(unittest.TestCase):
    def test_each_topic_has_three_actionable_lessons(self):
        self.assertEqual(set(csq.LESSONS), {"password", "phishing", "online_safety"})
        for lessons in csq.LESSONS.values():
            self.assertEqual(len(lessons), 3)
            for title, explanation, action in lessons:
                self.assertTrue(title.strip())
                self.assertTrue(explanation.strip())
                self.assertIn("Try this:", "Try this: " + action)

    def test_learning_center_displays_selected_topic(self):
        app = csq.App(store=csq.Store(path=Path(tempfile.gettempdir()) / "csq-learning-test.json"))
        with feed(["2"]):
            _, output = capture(app.learning_center)
        self.assertIn("Phishing awareness", output)
        self.assertIn("Spot suspicious messages", output)
        self.assertIn("Try this:", output)
